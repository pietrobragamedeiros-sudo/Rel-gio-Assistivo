# Roteiro de Demonstração Prática para a Banca do TCC

Este roteiro foi elaborado para que você apresente o sistema funcionando de ponta a ponta perante os professores e examinadores da banca de TCC.

---

## 1. Preparação Antes da Apresentação

1. **Ligue o Servidor Local:**
   No terminal, dentro da pasta do projeto, execute:
   ```bash
   node backend/server.js
   ```
   *(ou dê dois cliques no script de inicialização)*.
2. **Abra o Painel:**
   Acesse no navegador do notebook: `http://localhost:3000`.
   *(Se desejar demonstrar no celular também, conecte o celular no mesmo Wi-Fi e acesse `http://<IP_DO_NOTEBOOK>:3000`)*.
3. **Hardware do Relógio:**
   Ligue o cabo USB ou bateria do **ESP32-S3-Touch-LCD-1.28**.

> **Dica para a Banca (Plano B de Hardware):**  
> Caso a rede Wi-Fi da faculdade tenha bloqueios ou instabilidade, você pode utilizar o **Modo Demonstração (Simulador)** integrado na barra superior preta do site para demonstrar exatamente as mesmas respostas de rede, banco de dados, alertas sonoros e gráficos!

---

## 2. Passo a Passo da Demonstração ao Vivo

### Passo 1: Apresentação do Problema e Conceito (1 minuto)
* Explique à banca: *"Pessoas no espectro autista frequentemente enfrentam barreiras de comunicação verbal em momentos de sobrecarga sensorial ou dor. Este relógio foi projetado especificamente para um display circular compacto, com interface limpa, botões grandes e feedback bidirecional."*

### Passo 2: Pareamento Dinâmico com Código Temporário (2 minutos)
1. Mostre a tela do relógio:
   * O relógio inicializa, conecta ao Wi-Fi e exibe: **"Conectar Relógio"** com o código temporário (ex.: `A7K9P2`).
   * Explique à banca que o código possui validade limitada de 10 minutos para garantir segurança e privacidade, não sendo um identificador fixo gravado na fábrica.
2. No site do responsável:
   * Clique em **🔗 Conectar Relógio**.
   * Digite o código `A7K9P2` e o nome `João`.
   * Clique em **Conectar Agora**.
3. Aponte para a tela do relógio:
   * O relógio recebe o evento WebSocket em milissegundos e exibe: **"Relógio Conectado! Olá João!"**.
   * Três segundos depois, abre a tela principal com os botões de necessidades básicas.

### Passo 3: Envio de Solicitação Rotineira (Água) (1,5 minuto)
1. No relógio:
   * Toque no botão azul **ÁGUA**.
   * Mostre a tela de confirmação: *"Quer água? [SIM] [NÃO]"*.
   * Explique que essa tela intermediária evita disparos acidentais causados por movimentos repetitivos ou toques involuntários.
   * Toque em **SIM**.
   * O relógio exibe: *"Pedido Enviado! Aguarde o responsável"*.
2. No painel do responsável:
   * Aponte o som emitido pelo navegador (campainha suave gerada via Web Audio API).
   * Mostre o hero banner azul que surgiu instantaneamente: *"João quer beber água — 18:32"*.

### Passo 4: Confirmação Bidirecional ("Marcar como Atendido") (1 minuto)
1. No painel do responsável:
   * Clique no botão verde **✅ Marcar como Atendido**.
2. Aponte imediatamente para o relógio:
   * O relógio recebe a confirmação via WebSocket e exibe na tela o coração com a mensagem: **"Pedido Atendido! ❤️ A ajuda está a caminho"**.
   * Explique o impacto emocional e a previsibilidade que esse feedback traz para a pessoa autista.

### Passo 5: Demonstração de Emergência (Botão AJUDA / SOS) (1,5 minuto)
1. No relógio, toque no botão vermelho **AJUDA**.
2. Toque em **SIM, PRECISO**.
3. No painel do responsável:
   * Destaque o som de sirene/alarme pulsante de emergência.
   * Destaque a alteração visual com card em vermelho pulsante: **"⚠️ PEDIDO DE EMERGÊNCIA — João precisa de AJUDA IMEDIATA!"**.
   * Mostre que o sistema diferencia prioridades de rotina versus urgência.
4. Clique em **Marcar como Atendido**.

### Passo 6: Demonstração de Localização de Dor (1 minuto)
1. No relógio, selecione **DOR**.
2. Mostre o submenu: *Cabeça, Barriga, Peito, Braço, Perna, Outro*.
3. Selecione *Cabeça* $\rightarrow$ Confirme.
4. No site, mostre que o responsável recebe o card roxo especificando: *"Dor na Cabeça"*.

### Passo 7: Análise do Histórico e Métricas de Atendimento (1 minuto)
1. Role até a tabela de histórico no site.
2. Mostre os registros armazenados no banco de dados SQLite local:
   * Horário da solicitação.
   * Categoria e detalhes.
   * Status (Atendido).
   * Horário em que o responsável prestou atendimento.
3. Demonstre os filtros por **Hoje**, **Últimos 7 dias** e **Últimos 30 dias**, explicando como esses dados podem auxiliar a equipe multidisciplinar (médicos, fonoaudiólogos e psicólogos).

---

## 3. Principais Argumentos Técnicos para Responder à Banca

* **Por que não usar Bluetooth (BLE)?**  
  *Resposta:* O Bluetooth tem alcance restrito (cerca de 10 metros com obstáculos). O Wi-Fi com WebSocket permite que o responsável esteja em qualquer cômodo da residência ou escola com cobertura de rede.
* **Por que WebSocket e não HTTP Polling?**  
  *Resposta:* O polling faz requisições repetitivas a cada segundo, consumindo bateria desnecessária no ESP32. O WebSocket mantém um socket TCP aberto com framing ultraleve (RFC 6455), gerando latência menor que 50 milissegundos e consumo energético mínimo.
* **Por que SQLite em vez de Firebase?**  
  *Resposta:* O SQLite garante funcionamento 100% autônomo e local, sem custos de API, sem risco de expiração de credenciais e sem depender de conexão com a internet externa no momento da avaliação.
