# Guia de Compilação e Gravação no ESP32-S3-Touch-LCD-1.28

Este guia orienta o passo a passo para compilar e gravar o firmware do **Relógio Assistivo** utilizando a **Arduino IDE** ou o **PlatformIO (VS Code)**.

---

## 1. Especificações do Hardware

* **Placa:** Waveshare ESP32-S3-Touch-LCD-1.28
* **Microcontrolador:** ESP32-S3 (Xtensa Dual-Core 240 MHz)
* **Memória:** 16 MB Flash / 8 MB Octal PSRAM (ou 4MB/2MB dependendo da versão)
* **Display:** 1.28" LCD Circular GC9A01 (240x240 pixels, SPI)
* **Touch:** CST816S Capacitivo (I2C, endereço `0x15`)
* **Pino Bateria:** GPIO 1 (ADC1 Canal 0 com divisor 2:1)

### Mapeamento Físico de Pinos

| Periférico | Função | Pino GPIO no ESP32-S3 |
| :--- | :--- | :--- |
| **GC9A01 (Display)** | SCLK | GPIO 10 |
| **GC9A01 (Display)** | MOSI (SDA) | GPIO 11 |
| **GC9A01 (Display)** | CS | GPIO 9 |
| **GC9A01 (Display)** | DC | GPIO 8 |
| **GC9A01 (Display)** | RST | GPIO 12 |
| **GC9A01 (Display)** | BL (Backlight) | GPIO 2 |
| **CST816S (Touch)** | SDA | GPIO 6 |
| **CST816S (Touch)** | SCL | GPIO 7 |
| **CST816S (Touch)** | INT | GPIO 5 |
| **CST816S (Touch)** | RST | GPIO 13 |
| **Bateria ADC** | Medição Vbat | GPIO 1 |

---

## 2. Método 1 — Utilizando a Arduino IDE (Recomendado para Iniciantes)

### Passo 1: Instalar o Suporte a Placas ESP32
1. Abra a Arduino IDE (versão 2.x recomendada).
2. Vá em **Arquivo > Preferências**.
3. No campo **URLs Adicionais do Gerenciador de Placas**, adicione:
   ```
   https://espressif.github.io/arduino-esp32/package_esp32_index.json
   ```
4. Clique em **OK**.
5. Abra **Ferramentas > Placa > Gerenciador de Placas**.
6. Busque por `esp32` (da Espressif Systems) e instale a versão mais recente.

### Passo 2: Instalar as Bibliotecas Necessárias
No menu **Ferramentas > Gerenciar Bibliotecas...**, pesquise e instale:
1. **lvgl** (versão 9.x ou 8.x) — por LVGL.
2. **ArduinoJson** (versão 7.x ou 6.x) — por Benoit Blanchon.
3. **WebSockets** — por Markus Sattler.

> **Importante sobre o `lv_conf.h`:**  
> Copie o arquivo `esp32/include/lv_conf.h` deste projeto para a pasta de bibliotecas do Arduino (`Documentos/Arduino/libraries/lv_conf.h`), no mesmo nível da pasta `lvgl/`.

### Passo 3: Configurar a Placa na Arduino IDE
No menu **Ferramentas**, selecione exatamente as seguintes opções:
* **Placa:** `ESP32S3 Dev Module`
* **Porta:** Selecione a porta COM correspondente ao seu cabo USB
* **USB CDC On Boot:** `Enabled` ⚠️ *(Essencial para que as mensagens Serial apareçam)*
* **CPU Frequency:** `240MHz (WiFi)`
* **Flash Mode:** `QIO 80MHz`
* **Flash Size:** `16MB (128Mb)`
* **Partition Scheme:** `16M Flash (3MB APP/9.9MB FAT)` ou `Huge APP (3MB No OTA/1MB SPIFFS)`
* **PSRAM:** `OPI PSRAM` (ou desabilitada se sua versão não possuir PSRAM)
* **Upload Speed:** `921600`

### Passo 4: Gravar o Firmware
1. Abra o arquivo `esp32/RelogioAssistivo.ino` na Arduino IDE.
2. No arquivo `include/config.h`, se desejar, configure o IP do seu computador na constante `SERVER_HOST`.
3. Clique no botão **Carregar** (ícone de seta $\rightarrow$).
4. Aguarde a compilação e gravação. Quando concluir, o relógio inicializará imediatamente!

---

## 3. Método 2 — Utilizando PlatformIO (VS Code)

Se preferir utilizar o PlatformIO no VS Code:

1. Abra a pasta `c:\Users\Braga\Documents\autista\esp32` no VS Code com a extensão PlatformIO instalada.
2. O arquivo `platformio.ini` já contém todas as dependências (`lvgl`, `ArduinoJson`, `WebSockets`) e flags de compilação configuradas.
3. Conecte o ESP32-S3 via cabo USB.
4. Execute no terminal integrado:
   ```bash
   pio run -t upload
   ```
5. Para acompanhar o monitor serial:
   ```bash
   pio device monitor
   ```

---

## 4. Solução de Problemas Comuns (Troubleshooting)

### A porta COM não aparece no computador
* Certifique-se de que está usando um cabo USB de **dados** e não apenas de carga.
* Para forçar o modo de gravação (Bootloader):
  1. Mantenha pressionado o botão **BOOT** na placa.
  2. Conecte o cabo USB ao computador (ou dê um clique rápido no botão **RST** enquanto segura o BOOT).
  3. Solte o botão **BOOT**. A porta COM aparecerá.

### A tela acende mas fica preta
* Verifique se o pino do backlight (`PIN_LCD_BL = 2`) está ativo.
* Certifique-se de que as constantes de SPI (`PIN_LCD_SCLK = 10`, `PIN_LCD_MOSI = 11`, `PIN_LCD_CS = 9`, `PIN_LCD_DC = 8`) correspondem à sua revisão de placa. Se necessário, edite em `include/config.h`.

### Erro de falta de memória (SRAM overflow)
* O projeto utiliza buffer parcial de 20 linhas (`DISP_BUF_SIZE = LCD_WIDTH * 20`), consumindo menos de 20KB de RAM, perfeitamente compatível mesmo sem PSRAM externa.
