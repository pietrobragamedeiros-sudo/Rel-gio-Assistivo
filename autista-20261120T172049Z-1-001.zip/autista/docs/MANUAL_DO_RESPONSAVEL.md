# Manual do Responsável — Painel de Monitoramento

Este manual descreve como utilizar a interface web do **Relógio Assistivo** para acompanhar e atender as solicitações da pessoa com autismo.

---

## 1. Primeiro Acesso e Pareamento do Relógio

1. Ao ligar o relógio pela primeira vez, ele exibirá a mensagem **"Conectar Relógio"** acompanhada de um código de 6 letras/números (por exemplo: `A7K9P2`).
2. No computador, celular ou tablet, abra o navegador e acerte o endereço do painel (geralmente `http://localhost:3000` ou `http://<IP_DO_COMPUTADOR>:3000`).
3. Clique no botão **🔗 Conectar Relógio** no topo da tela.
4. Digite o código exibido na tela do relógio e informe o nome do usuário assistido (exemplo: `João`).
5. Clique em **Conectar Agora**.
6. Instantaneamente, o relógio mudará para a tela verde com a mensagem **"Relógio Conectado! Olá João!"**, e após alguns segundos exibirá o menu de botões de necessidades básicas.

---

## 2. Recepção de Solicitações em Tempo Real

Quando a pessoa assistida toca em uma necessidade no relógio e confirma:

### A. Solicitações Rotineiras (Água, Comer, Banheiro, Dormir, Brincar, Remédio)
* O painel emite uma **campainha suave** e exibe um card azul/verde no topo da tela.
* Informa o nome do usuário, a necessidade exata (ex.: *"João quer beber água"*), o horário do envio e a porcentagem de bateria do relógio no momento do pedido.

### B. Solicitações de Emergência (Botão AJUDA / SOS)
* O painel emite um **alarme sonoro pulsante** contínuo e exibe uma caixa vermelha com bordas em destaque:
  > **⚠️ PEDIDO DE EMERGÊNCIA — João precisa de AJUDA IMEDIATA!**
* Serve para situações de crise sensorial, pânico ou necessidade urgente de suporte.

### C. Relato de Dor
* O painel exibe um card roxo indicando exatamente a região informada pelo usuário (ex.: *"Dor na Cabeça"*, *"Dor na Barriga"*).

---

## 3. Como Marcar como Atendido (Feedback Bidirecional)

1. Assim que você prestar assistência ou acolher o pedido, clique no botão verde **✅ Marcar como Atendido** no card da solicitação.
2. O sistema executará duas ações simultâneas:
   * No **painel**: O card é arquivado e a solicitação é movida para o histórico com a marcação *"Atendido"* e o horário exato.
   * No **relógio**: O relógio exibe imediatamente uma tela com coração/sucesso verde dizendo: **"Pedido Atendido! ❤️ A ajuda está a caminho"**, acalmando a pessoa assistida ao saber que seu pedido foi acolhido.

---

## 4. Consulta ao Histórico

Na parte inferior do painel, você pode acompanhar os registros de comunicação:
* **Hoje:** Exibe apenas as solicitações feitas no dia atual.
* **Últimos 7 dias:** Permite avaliar padrões semanais (ex.: horários com maior recorrência de pedidos de água ou crises de dor).
* **Últimos 30 dias:** Visão mensal consolidada para apresentação a médicos, fonoaudiólogos e terapeutas ocupacionais.

---

## 5. Cuidados com a Bateria

* No card **Bateria do Relógio**, acompanhe o percentual restante.
* Recomenda-se colocar o relógio para carregar via cabo USB Type-C sempre que atingir níveis inferiores a **20%**.
