# Arquitetura do Sistema — Relógio Assistivo para Pessoas Autistas

**Projeto de Trabalho de Conclusão de Curso (TCC)**  
**Tecnologia Assistiva para Comunicação Alternativa e Aumentativa (CAA)**  
**Hardware:** Waveshare ESP32-S3-Touch-LCD-1.28  

---

## 1. Visão Geral

Este documento descreve detalhadamente a arquitetura de hardware, software, rede e banco de dados do **Relógio Assistivo**. O sistema foi concebido para fornecer uma ponte de comunicação direta, simples e com mínimo atrito cognitivo entre uma pessoa autista e seu responsável (pai, mãe, cuidador, mediador escolar).

```
+---------------------------+       Wi-Fi 802.11       +---------------------------+
|                           |  <-------------------->  |                           |
|      ESP32-S3 (Relógio)   |     WebSocket / JSON     |     Servidor Node.js      |
|  Display Circular GC9A01  |                          |  SQLite + API REST + WS   |
|   Touch CST816S (I2C)     |                          |                           |
+---------------------------+                          +---------------------------+
                                                                     ^
                                                                     | WebSocket / HTTP
                                                                     v
                                                       +---------------------------+
                                                       |  Painel Web do Responsável|
                                                       |   (PC, Celular ou Tablet) |
                                                       |  Alertas Sonoros & Visuais|
                                                       +---------------------------+
```

---

## 2. Diagrama de Comunicação e Ciclo de Vida do Pedido

```mermaid
sequenceDiagram
    autonumber
    actor Autista as Pessoa Autista (Relógio)
    participant ESP as ESP32-S3 (Firmware)
    participant SRV as Servidor Backend (Node.js)
    participant DB as SQLite DB
    participant WEB as Painel do Responsável (Web)
    actor Cuidador as Responsável (Cuidador)

    Note over ESP,SRV: Fase 1: Pareamento Seguro
    ESP->>SRV: REGISTER_PAIR_CODE { device_id: "ESP32S3_A1B2", code: "A7K9P2" }
    SRV->>DB: Salva código temporário (expira em 10 min)
    Cuidador->>WEB: Digita "A7K9P2" e nome "João"
    WEB->>SRV: POST /api/pair { code: "A7K9P2", user_name: "João" }
    SRV->>DB: Valida código, gera auth_token e vincula dispositivo
    SRV-->>ESP: Evento WS "PAIRED" { user_name: "João", token: "..." }
    ESP-->>Autista: Tela: "Relógio Conectado! Olá João"

    Note over Autista,Cuidador: Fase 2: Envio de Solicitação
    Autista->>ESP: Toque em "ÁGUA"
    ESP-->>Autista: "Quer água? [SIM] [NÃO]"
    Autista->>ESP: Toque em [SIM]
    ESP->>SRV: Evento WS "REQUEST" { category: "AGUA", label: "Beber água", priority: "NORMAL", battery: 85 }
    SRV->>DB: INSERT INTO requests (status = 'PENDENTE')
    SRV-->>WEB: Broadcast WS "NEW_REQUEST"
    WEB-->>Cuidador: 🔔 Alerta Sonoro + Hero Banner "João quer beber água"
    ESP-->>Autista: Tela: "Pedido Enviado! Aguarde"

    Note over Cuidador,Autista: Fase 3: Atendimento e Confirmação Bidirecional
    Cuidador->>WEB: Clica em [Marcar como Atendido]
    WEB->>SRV: POST /api/request/attend { request_id: 1 }
    SRV->>DB: UPDATE requests SET status = 'ATENDIDO', attended_at = NOW()
    SRV-->>ESP: Evento WS "REQUEST_ATTENDED" { message: "A ajuda está a caminho" }
    ESP-->>Autista: Tela: "Pedido Atendido! ❤️ A ajuda está a caminho"
    SRV-->>WEB: Atualiza histórico em tempo real
```

---

## 3. Modelo de Dados (SQLite)

O banco de dados armazena os vínculos de dispositivos, códigos temporários de pareamento e o histórico de solicitações:

### Tabela `devices`
Armazena a telemetria e o estado do relógio:
* `id` (TEXT, PK): Identificador único baseado no MAC address do ESP32 (ex.: `ESP32S3_A1B2C3`).
* `user_name` (TEXT): Nome da pessoa assistida (ex.: `João`).
* `battery` (INTEGER): Porcentagem de bateria reportada (0 a 100).
* `battery_voltage` (REAL): Tensão medida no divisor analógico (ex.: 4.12V).
* `is_online` (INTEGER): Flag binária de conectividade WebSocket ativa (1 = Online, 0 = Offline).
* `paired_token` (TEXT): Token de autenticação seguro após o pareamento.
* `last_activity` (DATETIME): Timestamp da última comunicação.
* `created_at` (DATETIME): Data do primeiro vínculo.

### Tabela `pairing_codes`
Armazena códigos temporários de curta duração:
* `code` (TEXT, PK): Código de 6 caracteres alfanuméricos legíveis (ex.: `A7K9P2`).
* `device_id` (TEXT): Identificador do relógio que gerou o código.
* `created_at` (INTEGER): Milissegundos Unix de criação.
* `expires_at` (INTEGER): Milissegundos Unix de expiração (10 minutos).

### Tabela `requests`
Histórico de todas as necessidades comunicadas:
* `id` (INTEGER, PK, AUTOINCREMENT): Identificador sequencial da solicitação.
* `device_id` (TEXT): Relógio de origem.
* `category` (TEXT): Categoria padronizada (`AGUA`, `COMER`, `BANHEIRO`, `DORMIR`, `BRINCAR`, `AJUDA`, `DOR`, `REMEDIO`).
* `label` (TEXT): Rótulo legível (ex.: "Beber água").
* `details` (TEXT): Informações complementares (ex.: "Dor: Cabeça").
* `priority` (TEXT): `NORMAL`, `ALTA` ou `EMERGENCIA`.
* `status` (TEXT): `PENDENTE` ou `ATENDIDO`.
* `battery_at_time` (INTEGER): Nível de bateria no momento do pedido.
* `created_at` (DATETIME): Data e hora do pedido.
* `attended_at` (DATETIME): Data e hora em que o responsável marcou como atendido.

---

## 4. Projeto da Interface Gráfica Circular (LVGL 9)

O display do **Waveshare ESP32-S3-Touch-LCD-1.28** possui formato circular de 240x240 pixels. Telas circulares impõem restrições de geometria:
* **Zona Segura:** O diâmetro útil sem corte de cantos é um círculo de raio 120px com centro em (120, 120). Cantos externos (x=0, y=0 ou x=240, y=0) não possuem pixels físicos.
* **Tamanho de Toque:** Os botões foram desenhados com largura de 170px a 190px e altura de 42px a 48px, com raio de borda totalmente arredondado (`radius = 24px`), facilitando o acionamento mesmo por crianças ou pessoas com dificuldades motoras finas.
* **Prevenção de Toques Acidentais:** Toques em itens essenciais disparam uma tela intermediária com os botões **SIM** (verde) e **NÃO** (vermelho).
* **Fluxo Diferenciado de Emergência (SOS):** O botão **AJUDA** possui fundo vermelho vivo e solicita confirmação explícita (*"Precisa de ajuda? [SIM, PRECISO] [CANCELAR]"*), emitindo alerta sonoro e visual diferenciado no site.
* **Fluxo de Dor:** Permite selecionar de forma visual e imediata qual parte do corpo está doendo (Cabeça, Barriga, Peito, Braço, Perna, Outro), transmitindo essa informação ao responsável.

---

## 5. Análise de Segurança do Protótipo

1. **Expiração de Códigos de Pareamento:** Os códigos temporários de 6 caracteres expiram em 10 minutos e são de uso único (invalidados imediatamente após o pareamento).
2. **Alfabeto Seguro:** O gerador de códigos exclui caracteres ambíguos (`0`, `O`, `1`, `I`) para evitar erros de digitação pelo responsável.
3. **Isolamento de Credenciais:** As credenciais Wi-Fi e os tokens são gravados na partição NVS criptografável do ESP32 via biblioteca `Preferences`, sem exposição no código-fonte.
4. **Limitações Conhecidas do Protótipo:** Em ambiente de produção comercial, recomenda-se ativar WSS (WebSocket sobre TLS/HTTPS) com certificado SSL no Node.js e habilitar o Flash Encryption e Secure Boot no ESP32-S3. Para fins acadêmicos de bancas de TCC, a comunicação via HTTP/WS em rede local fechada garante estabilidade sem depender de autoridades certificadoras externas.
