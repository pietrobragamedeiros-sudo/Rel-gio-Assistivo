/**
 * app.js — Lógica do Painel do Responsável
 * Relógio Assistivo para Pessoas Autistas — TCC
 *
 * Funciona tanto conectado ao backend Node.js (localhost:3000)
 * quanto conectado diretamente ao ESP32 (192.168.4.1).
 */

let pareado    = false;
let audioCtx   = null;
let historico  = [];
let ultimoPedido = 'nenhum';

// Mapa de ícones por pedido
const icones = {
  'Agua':       '💧',
  'Comer':      '🍴',
  'Banheiro':   '🚽',
  'Ajuda':      '🆘',
  'Brincar':    '🎮',
  'Sono':       '😴',
  'Incomodado': '😣',
};

// ============================================================
// ÁUDIO (Web Audio API)
// ============================================================
function initAudio() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if (audioCtx.state === 'suspended') audioCtx.resume();
}
document.addEventListener('click', initAudio, { once: true });

function tocarSom(urgente) {
  try {
    initAudio();
    const now  = audioCtx.currentTime;
    const osc  = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = urgente ? 'sawtooth' : 'sine';
    osc.frequency.setValueAtTime(urgente ? 880 : 523.25, now);
    if (urgente) osc.frequency.setValueAtTime(659.25, now + 0.15);
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + (urgente ? 0.6 : 0.4));
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start(now);
    osc.stop(now + (urgente ? 0.6 : 0.4));
  } catch(e) {}
}

// ============================================================
// PAREAMENTO
// ============================================================
async function conectarRelogio() {
  const cod = document.getElementById('inputCodigo').value.trim().toUpperCase();
  if (!cod) return;
  document.getElementById('msgErro').style.display = 'none';

  try {
    const res  = await fetch('/api/conectar?codigo=' + encodeURIComponent(cod));
    const data = await res.json();
    if (data.status === 'ok') {
      marcarOnline();
      tocarSom(false);
      alert('🎉 Relógio conectado com sucesso!');
    } else {
      document.getElementById('msgErro').style.display = 'block';
    }
  } catch(err) {
    alert('Erro ao conectar. Verifique se está no Wi-Fi "Relogio-Assistivo" e acesse 192.168.4.1');
  }
}

function marcarOnline() {
  pareado = true;
  document.getElementById('blocoPareamento').style.display = 'none';
  document.getElementById('badgeStatus').className = 'badge badge-online';
  document.getElementById('txtStatus').textContent  = 'Online';
}

// ============================================================
// MARCAR ATENDIDO
// ============================================================
async function marcarAtendido() {
  try {
    await fetch('/api/atendido', { method: 'POST' });
    tocarSom(false);
    renderPedidoNenhum();
  } catch(e) {}
}

// ============================================================
// RENDER
// ============================================================
function renderPedidoNenhum() {
  document.getElementById('blocoAtivo').innerHTML = `
    <div class="card card-vazio">
      <div class="vazio-icon">✨</div>
      <h2>Nenhuma solicitação pendente</h2>
      <p>Quando o usuário tocar no relógio, o chamado aparecerá aqui com som e alerta.</p>
    </div>`;
}

function renderPedidoAtivo(pedido, bateria) {
  const isSos   = pedido.toUpperCase().includes('AJUDA');
  const icone   = icones[pedido] || '📣';
  const hora    = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  document.getElementById('blocoAtivo').innerHTML = `
    <div class="active-card ${isSos ? 'sos' : ''}">
      <div class="active-icon">${icone}</div>
      <div class="active-title">${pedido}</div>
      <div class="active-time">Solicitado às ${hora} · Bateria: ${bateria || '--'}%</div>
      <button class="btn btn-success" onclick="marcarAtendido()">✅ Marcar como Atendido</button>
    </div>`;
  tocarSom(isSos);
}

function atualizarHistorico() {
  const el = document.getElementById('listaHistorico');
  if (historico.length === 0) { el.innerHTML = '<div class="vazio-txt">Nenhum chamado atendido ainda.</div>'; return; }
  el.innerHTML = historico.map(h => `
    <div class="history-item">
      <span class="history-label">${icones[h.label] || '📣'} ${h.label}</span>
      <span class="history-time">Atendido às ${h.time}</span>
    </div>`).join('');
}

// ============================================================
// POLLING DE STATUS (consulta o ESP32 a cada 1 segundo)
// ============================================================
async function verificarStatus() {
  try {
    const res  = await fetch('/api/status');
    const data = await res.json();

    // Auto-conecta se o relógio já estiver pareado
    if (data.pareado && !pareado) marcarOnline();

    if (data.pedido_atual && data.pedido_atual !== 'nenhum') {
      if (data.pedido_atual !== ultimoPedido) {
        ultimoPedido = data.pedido_atual;
        renderPedidoAtivo(data.pedido_atual, data.bateria);
      }
    } else {
      if (ultimoPedido !== 'nenhum') {
        const hora = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        historico.unshift({ label: ultimoPedido, time: hora });
        atualizarHistorico();
        ultimoPedido = 'nenhum';
        renderPedidoNenhum();
      }
    }
  } catch(e) {}
}

// Inicia o polling a cada 1 segundo
setInterval(verificarStatus, 1000);
