#include <Arduino_GFX_Library.h>
#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <Wire.h>

// --- DEFINICAO DE CORES (RGB565) ---
#define BLACK       0x0000
#define WHITE       0xFFFF
#define RED         0xF800
#define GREEN       0x07E0
#define BLUE        0x001F
#define CYAN        0x07FF
#define MAGENTA     0xF81F
#define YELLOW      0xFFE0
#define ORANGE      0xFD20
#define DARKGREEN   0x03E0
#define DARKCYAN    0x03EF
#define LIGHTGREY   0xC618
#define DARKGREY    0x7BEF

// ============================================================
// 1. CONFIGURACOES DA TELA E TOUCH
// ============================================================
#define TFT_BL 2
Arduino_DataBus *bus = new Arduino_ESP32SPI(8, 9, 10, 11, GFX_NOT_DEFINED);
Arduino_GFX    *gfx = new Arduino_GC9A01(bus, 14, 0, true);

#define TOUCH_SDA  6
#define TOUCH_SCL  7
#define TOUCH_RST 13
#define TOUCH_INT  5
#define TOUCH_ADDR 0x15

const char* ap_ssid     = "Relogio-Assistivo";
const char* ap_password = "";

AsyncWebServer server(80);

// ============================================================
// 2. VARIAVEIS DE ESTADO
// ============================================================
String codigo_pareamento  = "";
bool   dispositivo_pareado = false;
bool   menu_desenhado      = false;
String pedido_atual        = "nenhum";
String detalhes_pedido     = "";
String nome_usuario        = "Usuario";
int    nivel_bateria       = 88;

unsigned long tempo_ultimo_toque    = 0;
unsigned long tempo_tela_temporaria = 0;
bool          exibindo_tela_temporaria = false;

// NAVEGACAO: 0=Relogio | 1=Pedidos 1 | 2=Pedidos 2 | 3=Comunicacao Direta
int  paginaAtual = 0;
unsigned long tempo_ultimo_relogio = 0;
int  hora_sim = 10;
int  min_sim  = 30;

uint16_t      swipe_start_x    = 0;
uint16_t      swipe_start_y    = 0;
bool          aguardando_swipe  = false;
unsigned long tempo_inicio_toque = 0;

// ============================================================
// 3. SITE HTML (INLINE) COM AUTO-SYNC DE HORA
// ============================================================
const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Relógio Assistivo — Painel</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, sans-serif; }
    body { background: #0f172a; color: #f8fafc; min-height: 100vh; display: flex; flex-direction: column; }
    header { background: #1e293b; padding: 1rem 1.5rem; border-bottom: 1px solid #334155; display: flex; justify-content: space-between; align-items: center; }
    .brand { display: flex; align-items: center; gap: 0.75rem; }
    .brand-icon { font-size: 1.8rem; }
    .brand h1 { font-size: 1.25rem; font-weight: 700; color: #38bdf8; }
    .brand p  { font-size: 0.8rem; color: #94a3b8; }
    .badge { padding: 0.35rem 0.8rem; border-radius: 9999px; font-size: 0.85rem; font-weight: 700; display: inline-flex; align-items: center; gap: 0.4rem; }
    .badge-online  { background: #064e3b; color: #34d399; }
    .badge-offline { background: #7f1d1d; color: #f87171; }
    .dot { width: 8px; height: 8px; border-radius: 50%; background: currentColor; }
    main { flex: 1; max-width: 650px; width: 100%; margin: 0 auto; padding: 1.5rem 1rem; display: flex; flex-direction: column; gap: 1.5rem; }
    .card { background: #1e293b; border: 1px solid #334155; border-radius: 16px; padding: 1.5rem; }
    .card h2 { font-size: 1.2rem; margin-bottom: 0.5rem; color: #f8fafc; }
    .card p  { font-size: 0.9rem; color: #94a3b8; margin-bottom: 1.25rem; }
    .input-group { display: flex; flex-direction: column; gap: 0.5rem; margin-bottom: 0.75rem; }
    input { width: 100%; padding: 0.75rem 1rem; background: #0f172a; border: 1.5px solid #334155; border-radius: 10px; color: white; font-size: 1.2rem; text-align: center; text-transform: uppercase; font-weight: 700; letter-spacing: 2px; }
    input:focus { outline: none; border-color: #38bdf8; }
    .btn { width: 100%; padding: 0.75rem 1.25rem; border-radius: 10px; font-size: 1rem; font-weight: 700; border: none; cursor: pointer; transition: all 0.2s; }
    .btn-primary { background: #2563eb; color: white; }
    .btn-success { background: #16a34a; color: white; padding: 1rem; font-size: 1.15rem; }
    .active-card { border: 2px solid #38bdf8; background: #1e293b; border-radius: 18px; padding: 1.5rem; text-align: center; animation: pulse-border 2s infinite; }
    .active-card.sos { border-color: #ef4444; background: #450a0a; animation: pulse-sos 1s infinite alternate; }
    @keyframes pulse-border { 0%,100%{box-shadow:0 0 10px rgba(56,189,248,0.3)} 50%{box-shadow:0 0 25px rgba(56,189,248,0.7)} }
    @keyframes pulse-sos    { 0%{box-shadow:0 0 10px rgba(239,68,68,0.4)} 100%{box-shadow:0 0 30px rgba(239,68,68,0.8)} }
    .active-icon  { font-size: 4rem; margin-bottom: 0.5rem; }
    .active-title { font-size: 1.8rem; font-weight: 800; margin-bottom: 0.35rem; }
    .active-time  { font-size: 0.9rem; color: #94a3b8; margin-bottom: 1.5rem; }
    .history-item { display: flex; justify-content: space-between; padding: 0.85rem 0; border-bottom: 1px solid #334155; }
    .history-item:last-child { border-bottom: none; }
  </style>
</head>
<body>
  <header>
    <div class="brand"><div class="brand-icon">🕒</div><div><h1>Relógio Assistivo</h1><p>Painel do Responsável</p></div></div>
    <div><span id="badgeStatus" class="badge badge-offline"><span class="dot"></span><span id="txtStatus">Desconectado</span></span></div>
  </header>
  <main>
    <div class="card" id="blocoPareamento">
      <h2>Conectar ao Relógio</h2><p>Digite o código da tela do relógio:</p>
      <div class="input-group">
        <input type="text" id="inputCodigo" placeholder="Ex: 1234" maxlength="4">
        <button class="btn btn-primary" onclick="conectarRelogio()">🔗 Conectar</button>
      </div>
      <div id="msgErro" style="color:#f87171;font-size:0.85rem;display:none;">Código incorreto.</div>
    </div>
    <div id="blocoAtivo">
      <div class="card" style="text-align:center;padding:2.5rem 1rem;color:#94a3b8;">
        <div style="font-size:3rem;margin-bottom:0.75rem;">✨</div>
        <h2 style="color:#f8fafc;font-size:1.2rem;">Nenhuma solicitação</h2>
      </div>
    </div>
    <div class="card">
      <h2 style="font-size:1.1rem;margin-bottom:1rem;">📋 Histórico</h2>
      <div id="listaHistorico"><div style="text-align:center;color:#64748b;padding:1rem;">Vazio.</div></div>
    </div>
  </main>
  <script>
    let pareado = false; let audioCtx = null; let historico = []; let ultimoPedido = 'nenhum';
    const icones = {'Água':'💧','Comer':'🍴','Banheiro':'🚽','Ajuda':'🆘','Brincar':'🎮','Sono':'😴','Incomodado':'😣'};

    function initAudio() { if(!audioCtx) audioCtx = new (window.AudioContext||window.webkitAudioContext)(); if(audioCtx.state==='suspended') audioCtx.resume(); }
    document.addEventListener('click', initAudio, { once: true });

    function tocarSom(urgente) {
      try { initAudio(); const now = audioCtx.currentTime; const osc = audioCtx.createOscillator(); const gain = audioCtx.createGain();
      osc.type = urgente ? 'sawtooth' : 'sine'; osc.frequency.setValueAtTime(urgente ? 880 : 523.25, now);
      if (urgente) osc.frequency.setValueAtTime(659.25, now + 0.15);
      gain.gain.setValueAtTime(0.3, now); gain.gain.exponentialRampToValueAtTime(0.001, now + (urgente?0.6:0.4));
      osc.connect(gain); gain.connect(audioCtx.destination); osc.start(now); osc.stop(now + (urgente?0.6:0.4)); } catch(e){}
    }

    async function conectarRelogio() {
      const cod = document.getElementById('inputCodigo').value.trim().toUpperCase(); if(!cod) return;
      try {
        const res = await fetch('/api/conectar?codigo=' + encodeURIComponent(cod)); const data = await res.json();
        if (data.status === 'ok') {
          pareado = true; document.getElementById('blocoPareamento').style.display = 'none';
          document.getElementById('badgeStatus').className = 'badge badge-online'; document.getElementById('txtStatus').textContent = 'Online';
          tocarSom(false); alert('Conectado!');
          // Auto-Sincroniza a Hora do Relogio!
          const d = new Date();
          fetch(`/api/hora?h=${d.getHours()}&m=${d.getMinutes()}`);
        } else { document.getElementById('msgErro').style.display = 'block'; }
      } catch(err) { alert('Erro ao conectar.'); }
    }

    async function marcarAtendido() { try { await fetch('/api/atendido', { method: 'POST' }); tocarSom(false); renderPedidoNenhum(); } catch(e) {} }

    function renderPedidoNenhum() {
      document.getElementById('blocoAtivo').innerHTML = `<div class="card" style="text-align:center;padding:2.5rem 1rem;color:#94a3b8;"><div style="font-size:3rem;margin-bottom:0.75rem;">✨</div><h2 style="color:#f8fafc;font-size:1.2rem;">Nenhuma solicitação pendente</h2></div>`;
    }

    async function verificarStatus() {
      try {
        const res = await fetch('/api/status'); const data = await res.json();
        if (data.pareado && !pareado) { pareado = true; document.getElementById('blocoPareamento').style.display = 'none'; document.getElementById('badgeStatus').className = 'badge badge-online'; document.getElementById('txtStatus').textContent = 'Online'; }
        if (data.pedido_atual && data.pedido_atual !== 'nenhum') {
          const isSos = data.pedido_atual.toUpperCase().includes('AJUDA');
          if (data.pedido_atual !== ultimoPedido) {
            tocarSom(isSos); ultimoPedido = data.pedido_atual; const icone = icones[data.pedido_atual] || '📣';
            const horaAtual = new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });
            document.getElementById('blocoAtivo').innerHTML = `<div class="active-card ${isSos?'sos':''}"><div class="active-icon">${icone}</div><div class="active-title">${data.pedido_atual}</div><div class="active-time">Solicitado às ${horaAtual}</div><button class="btn btn-success" onclick="marcarAtendido()">✅ Marcar como Atendido</button></div>`;
          }
        } else {
          if (ultimoPedido !== 'nenhum') {
            const horaAtual = new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });
            historico.unshift({ label: ultimoPedido, time: horaAtual });
            const c = document.getElementById('listaHistorico');
            c.innerHTML = historico.map(h => `<div class="history-item"><span style="font-weight:700">${icones[h.label]||'📣'} ${h.label}</span><span style="color:#94a3b8;font-size:0.85rem">às ${h.time}</span></div>`).join('');
            ultimoPedido = 'nenhum'; renderPedidoNenhum();
          }
        }
      } catch(e) {}
    }
    setInterval(verificarStatus, 1000);
  </script>
</body>
</html>
)rawliteral";

String gerarCodigo() {
  String c = ""; for(int i=0; i<4; i++) c += String(random(1, 10)); return c;
}
String fmt2(int n) { return (n < 10 ? "0" : "") + String(n); }

// ============================================================
// 4. DESENHO VETORIAL DE ICONES PARA O RELOGIO
// ============================================================
// Em vez de imagens pesadas (BMP/PNG), desenhamos as formas usando geometria nativa da tela.
void desenharIconeVetorial(int id, int cx, int cy, uint16_t corFundo) {
  switch (id) {
    case 0: // AGUA (Gota azul)
      gfx->fillCircle(cx, cy+4, 12, WHITE);
      gfx->fillTriangle(cx-11, cy+4, cx+11, cy+4, cx, cy-16, WHITE);
      break;
    case 1: // COMER (Prato e talher)
      gfx->fillCircle(cx, cy, 16, WHITE);
      gfx->fillCircle(cx, cy, 11, corFundo); // Prato vazado
      gfx->fillRect(cx-18, cy-10, 4, 20, WHITE); // Garfo simbolico
      break;
    case 2: // BANHEIRO (Vaso sanitario)
      gfx->fillRect(cx-8, cy-14, 16, 16, WHITE); // Caixa
      gfx->fillRoundRect(cx-12, cy, 24, 12, 6, WHITE); // Bacia
      break;
    case 3: // AJUDA / SOS (Cruz Medica)
      gfx->fillRect(cx-5, cy-16, 10, 32, WHITE);
      gfx->fillRect(cx-16, cy-5, 32, 10, WHITE);
      break;
    case 4: // BRINCAR (Controle)
      gfx->fillRoundRect(cx-18, cy-12, 36, 24, 12, WHITE);
      gfx->fillCircle(cx-8, cy, 4, BLACK); // D-pad
      gfx->fillCircle(cx+8, cy, 4, RED);   // Botao
      break;
    case 5: // SONO (Lua crescente)
      gfx->fillCircle(cx, cy, 14, WHITE);
      gfx->fillCircle(cx+6, cy-4, 12, corFundo); // Faz o corte da lua
      break;
    case 6: // INCOMODADO (Rosto triste)
      gfx->fillCircle(cx, cy, 16, WHITE);
      gfx->drawLine(cx-8, cy-4, cx-2, cy-2, BLACK); // Sobrancelha brava esq
      gfx->drawLine(cx+8, cy-4, cx+2, cy-2, BLACK); // Sobrancelha brava dir
      gfx->drawLine(cx-6, cy+6, cx+6, cy+6, BLACK); // Boca reta
      break;
    case 7: // SAIR / VOLTAR (Seta)
      gfx->fillTriangle(cx-12, cy, cx, cy-10, cx, cy+10, WHITE);
      gfx->fillRect(cx, cy-4, 12, 8, WHITE);
      break;
    case 8: // SIM (Check verde)
      gfx->fillCircle(cx, cy, 20, WHITE);
      gfx->drawLine(cx-10, cy, cx-2, cy+8, GREEN);
      gfx->drawLine(cx-9, cy, cx-2, cy+9, GREEN);
      gfx->drawLine(cx-2, cy+8, cx+12, cy-8, GREEN);
      gfx->drawLine(cx-2, cy+9, cx+12, cy-7, GREEN);
      break;
    case 9: // NAO (X vermelho)
      gfx->fillCircle(cx, cy, 20, WHITE);
      gfx->drawLine(cx-10, cy-10, cx+10, cy+10, RED);
      gfx->drawLine(cx-10, cy-9, cx+9, cy+10, RED);
      gfx->drawLine(cx-10, cy+10, cx+10, cy-10, RED);
      gfx->drawLine(cx-10, cy+9, cx+9, cy-10, RED);
      break;
    case 10: // FELIZ (Sorrindo)
      gfx->fillCircle(cx, cy, 20, WHITE);
      gfx->fillCircle(cx-6, cy-4, 3, BLACK);
      gfx->fillCircle(cx+6, cy-4, 3, BLACK);
      for(int i=0; i<3; i++) gfx->drawCircle(cx, cy+4, 8+i, BLACK); // Sorriso
      gfx->fillRect(cx-10, cy-4, 20, 8, WHITE);
      break;
    case 11: // TRISTE (Rosto triste)
      gfx->fillCircle(cx, cy, 20, WHITE);
      gfx->fillCircle(cx-6, cy-4, 3, BLACK);
      gfx->fillCircle(cx+6, cy-4, 3, BLACK);
      for(int i=0; i<3; i++) gfx->drawCircle(cx, cy+8, 8+i, BLACK); // Triste
      gfx->fillRect(cx-10, cy+8, 20, 10, WHITE);
      break;
  }
}

void desenharIndicadorPagina(int pagina) {
  gfx->fillRect(70, 223, 100, 14, BLACK);
  int cx = 90; // Agora sao 4 paginas
  for (int i = 0; i < 4; i++) {
    if (i == pagina) gfx->fillCircle(cx, 229, 4, WHITE);
    else gfx->drawCircle(cx, 229, 3, 0x4A69);
    cx += 20;
  }
}

void desenharBotao(int x, int y, int w, int h, uint16_t cor, int icon_id, const char* label) {
  gfx->fillRoundRect(x + 4, y + 4, w - 8, h - 8, 12, cor);
  desenharIconeVetorial(icon_id, x + w/2, y + h/2 - 12, cor);
  gfx->setTextColor(WHITE); gfx->setTextSize(1);
  int lw = strlen(label) * 6;
  gfx->setCursor(x + (w - lw) / 2, y + (h / 2) + 16);
  gfx->print(label);
}

// ============================================================
// 5. TELAS DO SISTEMA
// ============================================================
void desenharTelaPareamento() {
  gfx->fillScreen(BLACK);
  gfx->drawCircle(120, 120, 118, 0x2945); gfx->drawCircle(120, 120, 116, 0x4A69);
  gfx->setTextColor(CYAN); gfx->setTextSize(1); gfx->setCursor(57, 42); gfx->print("CONECTAR AO SITE");
  gfx->drawFastHLine(48, 58, 144, 0x2945);
  gfx->setTextColor(DARKGREY); gfx->setCursor(68, 68); gfx->print("CODIGO DE ACESSO");
  
  gfx->fillRoundRect(28, 82, 184, 54, 12, 0x0014); gfx->drawRoundRect(28, 82, 184, 54, 12, CYAN);
  gfx->setTextColor(CYAN); gfx->setTextSize(4); gfx->setCursor(72, 92); gfx->print(codigo_pareamento);
  
  gfx->setTextColor(DARKGREY); gfx->setTextSize(1);
  gfx->setCursor(35, 150); gfx->print("Wi-Fi: Relogio-Assistivo");
  gfx->setCursor(52, 166); gfx->print("Acesse: 192.168.4.1");
}

void desenharConectado() {
  gfx->fillScreen(BLACK);
  gfx->drawCircle(120, 120, 118, GREEN); gfx->drawCircle(120, 120, 116, GREEN);
  gfx->setTextColor(GREEN); gfx->setTextSize(5); gfx->setCursor(86, 70); gfx->print("OK");
  gfx->setTextColor(WHITE); gfx->setTextSize(2);
  String saud = "Ola, " + nome_usuario + "!";
  gfx->setCursor(120 - (saud.length()*12)/2, 136); gfx->print(saud);
}

void desenharRelogio() {
  gfx->fillScreen(BLACK);
  gfx->drawCircle(120, 120, 118, 0x2945);

  String horaStr = fmt2(hora_sim) + ":" + fmt2(min_sim);
  gfx->setTextColor(WHITE); gfx->setTextSize(5);
  gfx->setCursor(120 - (horaStr.length()*30)/2, 80); gfx->print(horaStr);

  gfx->setTextColor(DARKGREY); gfx->setTextSize(1); gfx->setCursor(60, 136); gfx->print("Relogio Assistivo");
  gfx->drawFastHLine(48, 150, 144, 0x2945);

  if (dispositivo_pareado) { gfx->setTextColor(GREEN); gfx->setCursor(74, 160); gfx->print("* Conectado"); }
  else { gfx->setTextColor(RED); gfx->setCursor(60, 160); gfx->print("* Desconectado"); }

  gfx->setTextColor(0x4A69); gfx->setCursor(84, 198); gfx->print("< deslize >");
  desenharIndicadorPagina(0);
}

void desenharMenu1() { // Pedidos Basicos
  gfx->fillScreen(BLACK); gfx->drawCircle(120, 120, 118, 0x2945);
  desenharBotao(4,   4, 114, 108, BLUE,     0, "AGUA");
  desenharBotao(122, 4, 114, 108, ORANGE,   1, "COMER");
  desenharBotao(4, 116, 114, 108, DARKCYAN, 2, "BANHEIRO");
  desenharBotao(122,116, 114, 108, RED,      3, "AJUDA");
  desenharIndicadorPagina(1);
}

void desenharMenu2() { // Emoções / Outros
  gfx->fillScreen(BLACK); gfx->drawCircle(120, 120, 118, 0x2945);
  desenharBotao(4,   4, 114, 108, MAGENTA,  4, "BRINCAR");
  desenharBotao(122, 4, 114, 108, 0x000F,   5, "SONO");
  desenharBotao(4, 116, 114, 108, YELLOW,   6, "INCOMODADO");
  desenharBotao(122,116, 114, 108, 0x4A69,  7, "VOLTAR"); // Sair/Voltar para relogio
  desenharIndicadorPagina(2);
}

void desenharMenu3() { // NOVA TELA: COMUNICACAO EXPRESSA LOCAL
  gfx->fillScreen(BLACK); gfx->drawCircle(120, 120, 118, 0x2945);
  desenharBotao(4,   4, 114, 108, GREEN,   8, "SIM");
  desenharBotao(122, 4, 114, 108, RED,     9, "NAO");
  desenharBotao(4, 116, 114, 108, YELLOW, 10, "BOM");
  desenharBotao(122,116, 114, 108, BLUE,  11, "RUIM");
  desenharIndicadorPagina(3);
}

void desenharMenu() {
  if      (paginaAtual == 0) desenharRelogio();
  else if (paginaAtual == 1) desenharMenu1();
  else if (paginaAtual == 2) desenharMenu2();
  else if (paginaAtual == 3) desenharMenu3();
  menu_desenhado = true;
  exibindo_tela_temporaria = false;
}

// Tela enviada
void desenharPedidoEnviado(String nome) {
  gfx->fillScreen(BLACK);
  gfx->drawCircle(120, 120, 118, GREEN); gfx->drawCircle(120, 120, 116, GREEN);
  gfx->setTextColor(GREEN); gfx->setTextSize(2); gfx->setCursor(68, 62); gfx->print("ENVIADO!");
  gfx->setTextColor(ORANGE); gfx->setCursor(120 - (nome.length()*12)/2, 104); gfx->print(nome);
  gfx->setTextColor(DARKGREY); gfx->setTextSize(1); gfx->setCursor(26, 148); gfx->print("Aguarde o responsavel...");
  tempo_tela_temporaria = millis(); exibindo_tela_temporaria = true;
}

// Tela atendida
void desenharAtendido() {
  gfx->fillScreen(BLACK);
  gfx->drawCircle(120, 120, 118, GREEN); gfx->drawCircle(120, 120, 116, GREEN);
  gfx->setTextColor(GREEN); gfx->setTextSize(2); gfx->setCursor(44, 68); gfx->print("ATENDIDO!");
  gfx->setTextColor(WHITE); gfx->setTextSize(4); gfx->setCursor(86, 106); gfx->print(":)");
  gfx->setTextColor(DARKGREY); gfx->setTextSize(1); gfx->setCursor(24, 162); gfx->print("Ajuda a caminho! <3");
  tempo_tela_temporaria = millis(); exibindo_tela_temporaria = true;
}

// Resposta expressa Local (Mostra na tela inteira na mesma hora, para pessoas nao-verbais mostrarem)
void exibirComunicacaoExpressa(String msg, uint16_t cor) {
  gfx->fillScreen(cor);
  gfx->setTextColor(BLACK); 
  gfx->setTextSize(4);
  gfx->setCursor(120 - (msg.length()*24)/2, 100); 
  gfx->print(msg);
  tempo_tela_temporaria = millis(); 
  exibindo_tela_temporaria = true;
}

// ============================================================
// 6. HARDWARE E REDE
// ============================================================
void inicializarTouch() {
  pinMode(TOUCH_INT, INPUT_PULLUP); pinMode(TOUCH_RST, OUTPUT);
  digitalWrite(TOUCH_RST, LOW); delay(10); digitalWrite(TOUCH_RST, HIGH); delay(50);
  Wire.begin(TOUCH_SDA, TOUCH_SCL, 400000);
}
bool lerTouch(uint16_t &x, uint16_t &y) {
  Wire.beginTransmission(TOUCH_ADDR); Wire.write(0x02);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(TOUCH_ADDR, 5) != 5) return false;
  uint8_t toques = Wire.read(); if (toques == 0) return false;
  uint8_t xH = Wire.read(), xL = Wire.read(), yH = Wire.read(), yL = Wire.read();
  x = ((xH & 0x0F) << 8) | xL; y = ((yH & 0x0F) << 8) | yL;
  return (x < 240 && y < 240);
}

void dispararPedido(String nome, String detalhes) {
  pedido_atual = nome; detalhes_pedido = detalhes;
  desenharPedidoEnviado(nome);
}

void setup() {
  Serial.begin(115200); randomSeed(analogRead(1)); codigo_pareamento = gerarCodigo();
  pinMode(TFT_BL, OUTPUT); digitalWrite(TFT_BL, HIGH);
  gfx->begin(); desenharTelaPareamento();
  inicializarTouch();
  
  WiFi.mode(WIFI_AP); WiFi.softAP(ap_ssid, ap_password);
  
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *req){ req->send_P(200, "text/html", index_html); });
  
  // Sincroniza a hora vinda do celular automaticamente!
  server.on("/api/hora", HTTP_GET, [](AsyncWebServerRequest *req){
    if (req->hasParam("h") && req->hasParam("m")) {
      hora_sim = req->getParam("h")->value().toInt();
      min_sim  = req->getParam("m")->value().toInt();
      tempo_ultimo_relogio = millis(); 
      if (paginaAtual == 0) desenharRelogio();
    }
    req->send(200, "application/json", "{\"status\":\"ok\"}");
  });

  server.on("/api/conectar", HTTP_GET, [](AsyncWebServerRequest *req){
    if (req->hasParam("codigo") && req->getParam("codigo")->value() == codigo_pareamento) {
      dispositivo_pareado = true;
      req->send(200, "application/json", "{\"status\":\"ok\"}");
    } else req->send(200, "application/json", "{\"status\":\"erro\"}");
  });
  
  server.on("/api/status", HTTP_GET, [](AsyncWebServerRequest *req){
    String r = "{\"pareado\":" + String(dispositivo_pareado?"true":"false") + ",\"pedido_atual\":\"" + pedido_atual + "\"}";
    req->send(200, "application/json", r);
  });
  
  server.on("/api/atendido", HTTP_POST, [](AsyncWebServerRequest *req){
    pedido_atual = "nenhum"; desenharAtendido();
    req->send(200, "application/json", "{\"status\":\"ok\"}");
  });
  
  server.begin();
}

void loop() {
  unsigned long agora = millis();

  if (dispositivo_pareado && !menu_desenhado) { desenharConectado(); delay(2000); paginaAtual = 1; desenharMenu(); }
  
  // Telas temporarias somem depois de 3 segundos
  if (exibindo_tela_temporaria && (agora - tempo_tela_temporaria > 3000)) desenharMenu();

  // Relogio conta sozinho
  if (dispositivo_pareado && menu_desenhado && !exibindo_tela_temporaria && paginaAtual == 0) {
    if (agora - tempo_ultimo_relogio > 60000) {
      tempo_ultimo_relogio = agora; min_sim++;
      if (min_sim >= 60) { min_sim = 0; hora_sim = (hora_sim + 1) % 24; }
      desenharRelogio();
    }
  }

  // Toque na tela
  if (dispositivo_pareado && menu_desenhado && !exibindo_tela_temporaria) {
    uint16_t tx = 0, ty = 0;
    if (lerTouch(tx, ty)) {
      if (!aguardando_swipe) { swipe_start_x = tx; swipe_start_y = ty; aguardando_swipe = true; tempo_inicio_toque = agora; }
      
      // Reconhece o Deslize (Swipe)
      if (aguardando_swipe && (agora - tempo_inicio_toque > 80) && (agora - tempo_inicio_toque < 600)) {
        int dx = (int)tx - (int)swipe_start_x;
        if (abs(dx) > 55) {
          aguardando_swipe = false; tempo_ultimo_toque = agora;
          if (dx < 0) paginaAtual = (paginaAtual + 1) % 4; // Agora sao 4 paginas!
          else paginaAtual = (paginaAtual + 3) % 4;        
          desenharMenu(); delay(20); return;
        }
      }
    } else {
      if (aguardando_swipe) {
        unsigned long d = agora - tempo_inicio_toque; aguardando_swipe = false;
        
        // Toque Simples
        if (d > 0 && d < 500 && (agora - tempo_ultimo_toque > 500)) {
          tempo_ultimo_toque = agora;
          
          if (paginaAtual == 0) { paginaAtual = 1; desenharMenu(); }
          else if (paginaAtual == 1) { // Pedidos 1
            if      (swipe_start_x < 120 && swipe_start_y < 120) dispararPedido("Agua", "");
            else if (swipe_start_x >=120 && swipe_start_y < 120) dispararPedido("Comer", "");
            else if (swipe_start_x < 120 && swipe_start_y >=120) dispararPedido("Banheiro", "");
            else if (swipe_start_x >=120 && swipe_start_y >=120) dispararPedido("Ajuda", "");
          } else if (paginaAtual == 2) { // Pedidos 2
            if      (swipe_start_x < 120 && swipe_start_y < 120) dispararPedido("Brincar", "");
            else if (swipe_start_x >=120 && swipe_start_y < 120) dispararPedido("Sono", "");
            else if (swipe_start_x < 120 && swipe_start_y >=120) dispararPedido("Incomodado", "");
            else if (swipe_start_x >=120 && swipe_start_y >=120) { paginaAtual = 0; desenharMenu(); } // Volta
          } else if (paginaAtual == 3) { 
            // TELA 3: COMUNICACAO DIRETA (Sim/Nao) - Muito usado em autismo nao-verbal!
            // Pisca a resposta em tela cheia pra criança apontar/mostrar para alguém! (Nao avisa no site)
            if      (swipe_start_x < 120 && swipe_start_y < 120) exibirComunicacaoExpressa("SIM", GREEN);
            else if (swipe_start_x >=120 && swipe_start_y < 120) exibirComunicacaoExpressa("NAO", RED);
            else if (swipe_start_x < 120 && swipe_start_y >=120) exibirComunicacaoExpressa("BOM", YELLOW);
            else if (swipe_start_x >=120 && swipe_start_y >=120) exibirComunicacaoExpressa("RUIM", CYAN);
          }
        }
      }
    }
  }
  delay(20);
}