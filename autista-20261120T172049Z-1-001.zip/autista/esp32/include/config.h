#pragma once

/**
 * ============================================================================
 * CONFIGURAÇÕES GERAIS DE HARDWARE E SOFTWARE — RELÓGIO ASSISTIVO (TCC)
 * Dispositivo Alvo: Waveshare ESP32-S3-Touch-LCD-1.28
 * ============================================================================
 */

// --- IDENTIFICAÇÃO DO SISTEMA ---
#define DEVICE_MODEL_NAME       "ESP32-S3-Watch-1.28"
#define FIRMWARE_VERSION        "1.0.0-TCC"

// --- DIMENSÕES DA TELA CIRCULAR ---
#define LCD_WIDTH               240
#define LCD_HEIGHT              240
#define LCD_ROTATION            0     // 0, 1, 2, 3

// ============================================================================
// MAPEAMENTO DE PINOS (GPIO) — WAVESHARE ESP32-S3-Touch-LCD-1.28
// ============================================================================

// Display LCD GC9A01 (Interface SPI)
#define PIN_LCD_SCLK            10    // SPI SCLK
#define PIN_LCD_MOSI            11    // SPI MOSI (SDA do display)
#define PIN_LCD_MISO            -1    // Não conectado / unidirecional
#define PIN_LCD_CS              9     // Chip Select do LCD
#define PIN_LCD_DC              8     // Data / Command
#define PIN_LCD_RST             12    // Reset do LCD
#define PIN_LCD_BL              2     // Backlight (Controle de brilho PWM)

// Frequência do barramento SPI (40MHz a 80MHz)
#define LCD_SPI_FREQUENCY       40000000

// Touchscreen Capacitivo CST816S (Interface I2C)
#define PIN_TOUCH_SDA           6     // I2C SDA
#define PIN_TOUCH_SCL           7     // I2C SCL
#define PIN_TOUCH_INT           5     // Interrupção Touch (Falling edge)
#define PIN_TOUCH_RST           13    // Reset do Touch
#define TOUCH_I2C_ADDR          0x15  // Endereço I2C do CST816S
#define TOUCH_I2C_FREQ          400000// 400kHz I2C Fast Mode

// Monitoramento de Bateria
#define PIN_BAT_ADC             1     // ADC1 Canal 0 (divisor de tensão 2:1)
#define BAT_DIVIDER_RATIO       2.0f  // Fator multiplicador do divisor de tensão
#define BAT_VOLTAGE_MIN         3.30f // Voltagem equivalente a 0%
#define BAT_VOLTAGE_MAX         4.20f // Voltagem equivalente a 100%

// ============================================================================
// CONFIGURAÇÕES DE REDE WI-FI E SERVIDOR BACKEND
// ============================================================================

// Credenciais Wi-Fi Padrão de Contingência (Para testes rápidos e apresentação do TCC)
// Caso o Wi-Fi salvo no NVS falhe, o ESP32 tentará conectar aqui antes de abrir o Portal
#define DEFAULT_WIFI_SSID       "SuaRedeWiFi"
#define DEFAULT_WIFI_PASS       "SuaSenhaWiFi"

// SoftAP para Configuração de Wi-Fi via Celular (Captive Portal)
#define AP_SSID                 "Relogio-Assistivo"
#define AP_PASS                 ""    // Rede aberta para facilitar no protótipo
#define AP_IP_ADDRESS           "192.168.4.1"

// Endereço do Servidor Backend (IP da máquina executando backend/server.js)
// Altere para o IP local do seu computador (ex: "192.168.1.50" ou "192.168.0.105")
#define SERVER_HOST             "192.168.1.100"
#define SERVER_PORT             3000
#define WS_PATH                 "/ws/device"

// Intervalos de Tempo (em milissegundos)
#define PAIRING_CODE_TIMEOUT_MS 600000 // 10 minutos para expirar código de pareamento
#define HEARTBEAT_INTERVAL_MS   15000  // Envio de telemetria a cada 15 segundos
#define BATTERY_CHECK_MS        30000  // Leitura de bateria a cada 30 segundos
#define SCREEN_TIMEOUT_MS       60000  // Diminuir brilho após 60s de inatividade
