/**
 * @file lv_conf.h
 * Configuração otimizada do LVGL 9 para ESP32-S3-Touch-LCD-1.28
 */

#ifndef LV_CONF_H
#define LV_CONF_H

#include <stdint.h>

#define LV_USE_DEV_VERSION 0

/* Cor em 16 bits (RGB565) para o display GC9A01 */
#define LV_COLOR_DEPTH 16
#define LV_COLOR_16_SWAP 0

/* Alocação de memória para buffers internos do LVGL */
#define LV_MEM_SIZE (64 * 1024U)

/* Temporizador customizado utilizando millis() do Arduino */
#define LV_TICK_CUSTOM 1
#if LV_TICK_CUSTOM
    #define LV_TICK_CUSTOM_INCLUDE "Arduino.h"
    #define LV_TICK_CUSTOM_SYS_TIME_EXPR (millis())
#endif

/* Configuração de taxa de atualização (30ms = ~33 FPS) */
#define LV_DEF_REFR_PERIOD 30
#define LV_DPI_DEF 130

/* Fontes incluídas */
#define LV_FONT_MONTSERRAT_12 1
#define LV_FONT_MONTSERRAT_14 1
#define LV_FONT_MONTSERRAT_16 1
#define LV_FONT_MONTSERRAT_18 1
#define LV_FONT_MONTSERRAT_20 1
#define LV_FONT_MONTSERRAT_24 1
#define LV_FONT_MONTSERRAT_28 1
#define LV_FONT_DEFAULT &lv_font_montserrat_16

/* Habilitar widgets essenciais */
#define LV_USE_ARC        1
#define LV_USE_BAR        1
#define LV_USE_BTN        1
#define LV_USE_BTNMATRIX  1
#define LV_USE_CANVAS     0
#define LV_USE_CHECKBOX   1
#define LV_USE_DROPDOWN   0
#define LV_USE_IMAGE      1
#define LV_USE_LABEL      1
#define LV_USE_LINE       1
#define LV_USE_ROLLER     0
#define LV_USE_SLIDER     1
#define LV_USE_SWITCH     1
#define LV_USE_TEXTAREA   1
#define LV_USE_TABLE      0

/* Efeitos visuais e animações */
#define LV_USE_ANIMATION  1
#define LV_USE_SHADOW     1
#define LV_USE_OUTLINE    1
#define LV_USE_PATTERN    0
#define LV_USE_VALUE_STR  1

#endif /* LV_CONF_H */
