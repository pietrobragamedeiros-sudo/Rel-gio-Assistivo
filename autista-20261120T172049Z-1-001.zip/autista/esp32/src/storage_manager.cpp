#include "storage_manager.h"
#include <WiFi.h>

Preferences StorageManager::prefs;
String StorageManager::cachedDeviceId = "";

void StorageManager::init() {
  prefs.begin("relogio_cfg", false);

  // Gera Device ID único a partir dos 3 últimos bytes do MAC address
  uint8_t mac[6];
  WiFi.macAddress(mac);
  char buf[32];
  snprintf(buf, sizeof(buf), "ESP32S3_%02X%02X%02X", mac[3], mac[4], mac[5]);
  cachedDeviceId = String(buf);
}

String StorageManager::getDeviceId() {
  if (cachedDeviceId.length() == 0) {
    init();
  }
  return cachedDeviceId;
}

String StorageManager::getWiFiSSID() {
  return prefs.getString("wifi_ssid", DEFAULT_WIFI_SSID);
}

String StorageManager::getWiFiPass() {
  return prefs.getString("wifi_pass", DEFAULT_WIFI_PASS);
}

void StorageManager::saveWiFi(const String &ssid, const String &pass) {
  prefs.putString("wifi_ssid", ssid);
  prefs.putString("wifi_pass", pass);
}

bool StorageManager::hasSavedWiFi() {
  return prefs.isKey("wifi_ssid") && prefs.getString("wifi_ssid").length() > 0;
}

String StorageManager::getServerHost() {
  return prefs.getString("srv_host", SERVER_HOST);
}

uint16_t StorageManager::getServerPort() {
  return (uint16_t)prefs.getUInt("srv_port", SERVER_PORT);
}

void StorageManager::saveServerConfig(const String &host, uint16_t port) {
  prefs.putString("srv_host", host);
  prefs.putUInt("srv_port", port);
}

bool StorageManager::isPaired() {
  return prefs.isKey("paired_token") && prefs.getString("paired_token").length() > 0;
}

String StorageManager::getPairedToken() {
  return prefs.getString("paired_token", "");
}

String StorageManager::getUserName() {
  return prefs.getString("user_name", "João");
}

void StorageManager::savePairing(const String &token, const String &userName) {
  prefs.putString("paired_token", token);
  prefs.putString("user_name", userName);
}

void StorageManager::clearPairing() {
  prefs.remove("paired_token");
  prefs.remove("user_name");
}

uint8_t StorageManager::getBrightness() {
  return (uint8_t)prefs.getUChar("brightness", 85);
}

void StorageManager::saveBrightness(uint8_t val) {
  prefs.putUChar("brightness", val);
}
