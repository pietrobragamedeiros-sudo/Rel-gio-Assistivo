#include "display_gc9a01.h"

static SPIClass spiBus(FSPI);

void DisplayGC9A01::init() {
  pinMode(PIN_LCD_DC, OUTPUT);
  pinMode(PIN_LCD_CS, OUTPUT);
  pinMode(PIN_LCD_RST, OUTPUT);
  pinMode(PIN_LCD_BL, OUTPUT);

  digitalWrite(PIN_LCD_CS, HIGH);
  digitalWrite(PIN_LCD_DC, HIGH);

  // Inicializa barramento SPI para o ESP32-S3
  spiBus.begin(PIN_LCD_SCLK, PIN_LCD_MISO, PIN_LCD_MOSI, PIN_LCD_CS);

  // Configuração do Backlight (PWM com suporte a Core 2.x e Core 3.x do ESP32)
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(PIN_LCD_BL, 5000, 8); // 5kHz, resolução de 8 bits
#else
  ledcSetup(0, 5000, 8);
  ledcAttachPin(PIN_LCD_BL, 0);
#endif
  setBrightness(85); // 85% de brilho inicial

  hardwareReset();
  initCommands();
}

void DisplayGC9A01::setBrightness(uint8_t percentage) {
  if (percentage > 100) percentage = 100;
  uint32_t duty = (percentage * 255) / 100;
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(PIN_LCD_BL, duty);
#else
  ledcWrite(0, duty);
#endif
}

void DisplayGC9A01::hardwareReset() {
  digitalWrite(PIN_LCD_RST, HIGH);
  delay(10);
  digitalWrite(PIN_LCD_RST, LOW);
  delay(20);
  digitalWrite(PIN_LCD_RST, HIGH);
  delay(150);
}

void DisplayGC9A01::sendCommand(uint8_t cmd) {
  digitalWrite(PIN_LCD_DC, LOW);
  digitalWrite(PIN_LCD_CS, LOW);
  spiBus.beginTransaction(SPISettings(LCD_SPI_FREQUENCY, MSBFIRST, SPI_MODE0));
  spiBus.write(cmd);
  spiBus.endTransaction();
  digitalWrite(PIN_LCD_CS, HIGH);
}

void DisplayGC9A01::sendData(uint8_t data) {
  digitalWrite(PIN_LCD_DC, HIGH);
  digitalWrite(PIN_LCD_CS, LOW);
  spiBus.beginTransaction(SPISettings(LCD_SPI_FREQUENCY, MSBFIRST, SPI_MODE0));
  spiBus.write(data);
  spiBus.endTransaction();
  digitalWrite(PIN_LCD_CS, HIGH);
}

void DisplayGC9A01::sendDataBytes(const uint8_t *data, size_t len) {
  digitalWrite(PIN_LCD_DC, HIGH);
  digitalWrite(PIN_LCD_CS, LOW);
  spiBus.beginTransaction(SPISettings(LCD_SPI_FREQUENCY, MSBFIRST, SPI_MODE0));
  spiBus.writeBytes(data, len);
  spiBus.endTransaction();
  digitalWrite(PIN_LCD_CS, HIGH);
}

void DisplayGC9A01::setAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
  uint8_t xData[4] = { (uint8_t)(x0 >> 8), (uint8_t)(x0 & 0xFF), (uint8_t)(x1 >> 8), (uint8_t)(x1 & 0xFF) };
  uint8_t yData[4] = { (uint8_t)(y0 >> 8), (uint8_t)(y0 & 0xFF), (uint8_t)(y1 >> 8), (uint8_t)(y1 & 0xFF) };

  sendCommand(0x2A); // CASET: Column Address Set
  sendDataBytes(xData, 4);

  sendCommand(0x2B); // RASET: Row Address Set
  sendDataBytes(yData, 4);

  sendCommand(0x2C); // RAMWR: Memory Write
}

void DisplayGC9A01::pushColors(uint16_t *data, uint32_t len) {
  digitalWrite(PIN_LCD_DC, HIGH);
  digitalWrite(PIN_LCD_CS, LOW);
  spiBus.beginTransaction(SPISettings(LCD_SPI_FREQUENCY, MSBFIRST, SPI_MODE0));
  spiBus.writePixels(data, len * 2);
  spiBus.endTransaction();
  digitalWrite(PIN_LCD_CS, HIGH);
}

// Sequência padrão de inicialização dos registradores do controlador GC9A01
void DisplayGC9A01::initCommands() {
  sendCommand(0xEF);
  sendCommand(0xEB); sendData(0x14);
  sendCommand(0xFE);
  sendCommand(0xEF);
  sendCommand(0xEB); sendData(0x14);
  sendCommand(0x84); sendData(0x40);
  sendCommand(0x85); sendData(0xFF);
  sendCommand(0x86); sendData(0xFF);
  sendCommand(0x87); sendData(0xFF);
  sendCommand(0x88); sendData(0x0A);
  sendCommand(0x89); sendData(0x21);
  sendCommand(0x8A); sendData(0x00);
  sendCommand(0x8B); sendData(0x80);
  sendCommand(0x8C); sendData(0x01);
  sendCommand(0x8D); sendData(0x01);
  sendCommand(0x8E); sendData(0xFF);
  sendCommand(0x8F); sendData(0xFF);

  sendCommand(0xB6); sendData(0x00); sendData(0x00);
  sendCommand(0x36); sendData(0x08); // Orientação (BGR)
  sendCommand(0x3A); sendData(0x05); // 16-bit RGB565

  sendCommand(0x90); sendData(0x08); sendData(0x08); sendData(0x08); sendData(0x08);
  sendCommand(0xBD); sendData(0x06);
  sendCommand(0xBC); sendData(0x00);
  sendCommand(0xFF); sendData(0x60); sendData(0x01); sendData(0x04);
  sendCommand(0xC3); sendData(0x13);
  sendCommand(0xC4); sendData(0x13);
  sendCommand(0xC9); sendData(0x22);
  sendCommand(0xBE); sendData(0x11);

  sendCommand(0xE1); sendData(0x10); sendData(0x0E);
  sendCommand(0xDF); sendData(0x21); sendData(0x0c); sendData(0x02);

  // Gamma
  sendCommand(0xF0);
  sendData(0x45); sendData(0x09); sendData(0x08); sendData(0x08); sendData(0x26); sendData(0x2A);
  sendCommand(0xF1);
  sendData(0x43); sendData(0x70); sendData(0x72); sendData(0x36); sendData(0x37); sendData(0x6F);
  sendCommand(0xF2);
  sendData(0x45); sendData(0x09); sendData(0x08); sendData(0x08); sendData(0x26); sendData(0x2A);
  sendCommand(0xF3);
  sendData(0x43); sendData(0x70); sendData(0x72); sendData(0x36); sendData(0x37); sendData(0x6F);

  sendCommand(0xED); sendData(0x1B); sendData(0x0B);
  sendCommand(0xAE); sendData(0x77);
  sendCommand(0xCD); sendData(0x63);
  sendCommand(0x70); sendData(0x07); sendData(0x07); sendData(0x04); sendData(0x0E); sendData(0x0F); sendData(0x09); sendData(0x07); sendData(0x08); sendData(0x03);

  sendCommand(0xE8); sendData(0x34);

  sendCommand(0x11); // Sleep Out
  delay(120);
  sendCommand(0x29); // Display ON
  delay(20);
}

// Callback de Renderização do LVGL
#if LVGL_VERSION_MAJOR >= 9
void DisplayGC9A01::flushCallback(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map) {
  uint32_t width = (area->x2 - area->x1 + 1);
  uint32_t height = (area->y2 - area->y1 + 1);
  uint32_t len = width * height;

  setAddrWindow(area->x1, area->y1, area->x2, area->y2);
  pushColors((uint16_t *)px_map, len);

  lv_display_flush_ready(disp);
}
#else
void DisplayGC9A01::flushCallback(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p) {
  uint32_t width = (area->x2 - area->x1 + 1);
  uint32_t height = (area->y2 - area->y1 + 1);
  uint32_t len = width * height;

  setAddrWindow(area->x1, area->y1, area->x2, area->y2);
  pushColors((uint16_t *)color_p, len);

  lv_disp_flush_ready(disp);
}
#endif
