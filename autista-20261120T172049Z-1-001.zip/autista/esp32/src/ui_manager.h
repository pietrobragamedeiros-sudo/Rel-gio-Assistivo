#pragma once

#include <Arduino.h>
#include <lvgl.h>
#include "../include/config.h"

enum UIScreen {
  SCREEN_BOOT,
  SCREEN_PAIRING,
  SCREEN_CONNECTED,
  SCREEN_MAIN,
  SCREEN_MORE,
  SCREEN_CONFIRM,
  SCREEN_SOS_CONFIRM,
  SCREEN_PAIN_SELECT,
  SCREEN_SENT,
  SCREEN_ATTENDED
};

class UIManager {
public:
  static void init();
  static void showScreen(UIScreen screen);

  // Atualizações dinâmicas
  static void setPairingCode(const String &code);
  static void setStatusMessage(const String &msg);
  static void setUserName(const String &name);
  static void updateBattery(uint8_t percentage);
  static void showAttendedPopup(const String &label, const String &message);

  // Solicitação Pendente Atual para Confirmação
  static void prepareConfirmation(const String &cat, const String &label, const String &question, const String &prio = "NORMAL");
  static void confirmAndSendCurrent();

private:
  static void createStyles();
  static void buildBootScreen();
  static void buildPairingScreen();
  static void buildConnectedScreen();
  static void buildMainScreen();
  static void buildMoreScreen();
  static void buildConfirmScreen();
  static void buildSosConfirmScreen();
  static void buildPainSelectScreen();
  static void buildSentScreen();
  static void buildAttendedScreen();
};
