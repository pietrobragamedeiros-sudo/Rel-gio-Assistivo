#pragma once

#include <Arduino.h>
#include <functional>

enum NetworkState {
  NET_IDLE,
  NET_CONNECTING_WIFI,
  NET_CONNECTED_WIFI,
  NET_AP_PORTAL_ACTIVE,
  NET_WIFI_FAILED,
  NET_WS_CONNECTED,
  NET_WS_DISCONNECTED
};

typedef std::function<void(NetworkState state)> NetworkStateCallback;
typedef std::function<void(const String &code)> PairingCodeCallback;
typedef std::function<void(const String &userName)> PairedSuccessCallback;
typedef std::function<void(const String &label, const String &message)> RequestAttendedCallback;

class NetworkManager {
public:
  static void init();
  static void loop();

  // Conexão Wi-Fi
  static void connectWiFi();
  static void startCaptivePortal();
  static bool isWiFiConnected();
  static bool isWsConnected();
  static String getIP();

  // Pareamento
  static String generatePairingCode();
  static void sendPairingCode(const String &code);
  static void checkPairingStatus();

  // Envio de Solicitação
  static void sendAssistiveRequest(const String &category, const String &label, const String &details, const String &priority);

  // Callbacks para atualizar a interface gráfica
  static void onStateChanged(NetworkStateCallback cb);
  static void onPairingCode(PairingCodeCallback cb);
  static void onPairedSuccess(PairedSuccessCallback cb);
  static void onRequestAttended(RequestAttendedCallback cb);

private:
  static void handleWebSocketEvent(uint8_t type, uint8_t *payload, size_t length);
  static void sendHeartbeat();
};
