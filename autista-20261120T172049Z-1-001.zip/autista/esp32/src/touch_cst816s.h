#pragma once

#include <Arduino.h>
#include <Wire.h>
#include <lvgl.h>
#include "../include/config.h"

class TouchCST816S {
public:
  static void init();
  static bool getTouch(uint16_t &x, uint16_t &y);

  // Callbacks para LVGL
#if LVGL_VERSION_MAJOR >= 9
  static void readCallback(lv_indev_t *indev, lv_indev_data_t *data);
#else
  static void readCallback(lv_indev_drv_t *drv, lv_indev_data_t *data);
#endif

private:
  static void hardwareReset();
  static uint8_t readRegister(uint8_t reg);
  static bool readData(uint8_t *buffer, size_t len);
};
