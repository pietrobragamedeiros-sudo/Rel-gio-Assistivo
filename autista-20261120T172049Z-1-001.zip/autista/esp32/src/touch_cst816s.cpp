#include "touch_cst816s.h"

static uint16_t lastX = 0;
static uint16_t lastY = 0;
static bool wasTouched = false;

void TouchCST816S::init() {
  pinMode(PIN_TOUCH_INT, INPUT_PULLUP);
  pinMode(PIN_TOUCH_RST, OUTPUT);

  hardwareReset();

  Wire.begin(PIN_TOUCH_SDA, PIN_TOUCH_SCL, TOUCH_I2C_FREQ);
  delay(50);
}

void TouchCST816S::hardwareReset() {
  digitalWrite(PIN_TOUCH_RST, LOW);
  delay(10);
  digitalWrite(PIN_TOUCH_RST, HIGH);
  delay(50);
}

bool TouchCST816S::readData(uint8_t *buffer, size_t len) {
  Wire.beginTransmission(TOUCH_I2C_ADDR);
  Wire.write(0x01); // Começa leitura no registrador 0x01 (Gesture)
  if (Wire.endTransmission(false) != 0) {
    return false;
  }

  uint8_t received = Wire.requestFrom((uint8_t)TOUCH_I2C_ADDR, (uint8_t)len);
  if (received != len) {
    return false;
  }

  for (size_t i = 0; i < len; i++) {
    buffer[i] = Wire.read();
  }
  return true;
}

bool TouchCST816S::getTouch(uint16_t &x, uint16_t &y) {
  uint8_t data[6];
  // data[0]: Gesture ID (Reg 0x01)
  // data[1]: Finger num / points (Reg 0x02)
  // data[2]: X high 4 bits + event (Reg 0x03)
  // data[3]: X low 8 bits (Reg 0x04)
  // data[4]: Y high 4 bits (Reg 0x05)
  // data[5]: Y low 8 bits (Reg 0x06)

  if (!readData(data, 6)) {
    return false;
  }

  uint8_t fingerNum = data[1];
  if (fingerNum == 0) {
    wasTouched = false;
    return false;
  }

  uint16_t rawX = ((data[2] & 0x0F) << 8) | data[3];
  uint16_t rawY = ((data[4] & 0x0F) << 8) | data[5];

  // Limita aos limites da tela circular (240x240)
  if (rawX >= LCD_WIDTH) rawX = LCD_WIDTH - 1;
  if (rawY >= LCD_HEIGHT) rawY = LCD_HEIGHT - 1;

  x = rawX;
  y = rawY;
  lastX = x;
  lastY = y;
  wasTouched = true;

  return true;
}

#if LVGL_VERSION_MAJOR >= 9
void TouchCST816S::readCallback(lv_indev_t *indev, lv_indev_data_t *data) {
  uint16_t x = 0, y = 0;
  bool touched = getTouch(x, y);

  if (touched) {
    data->state = LV_INDEV_STATE_PRESSED;
    data->point.x = x;
    data->point.y = y;
  } else {
    data->state = LV_INDEV_STATE_RELEASED;
    data->point.x = lastX;
    data->point.y = lastY;
  }
}
#else
void TouchCST816S::readCallback(lv_indev_drv_t *drv, lv_indev_data_t *data) {
  uint16_t x = 0, y = 0;
  bool touched = getTouch(x, y);

  if (touched) {
    data->state = LV_INDEV_STATE_PRESSED;
    data->point.x = x;
    data->point.y = y;
  } else {
    data->state = LV_INDEV_STATE_RELEASED;
    data->point.x = lastX;
    data->point.y = lastY;
  }
}
#endif
