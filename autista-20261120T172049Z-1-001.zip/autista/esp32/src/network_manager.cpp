#include "network_manager.h"
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>
#include "storage_manager.h"
#include "battery_monitor.h"
#include "../include/config.h"

static WebSocketsClient webSocket;
static WebServer serverPortal(80);
static DNSServer dnsServer;

static NetworkState currentState = NET_IDLE;
static NetworkStateCallback stateCb = nullptr;
static PairingCodeCallback pairingCb = nullptr;
static PairedSuccessCallback pairedSuccessCb = nullptr;
static RequestAttendedCallback requestAttendedCb = nullptr;

static unsigned long lastHeartbeatTime = 0;
static unsigned long wifiConnectStartTime = 0;
static bool portalActive = false;
static String currentPairCode = "";

static void setState(NetworkState s) {
  currentState = s;
  if (stateCb) {
    stateCb(s);
  }
}

// Caracteres legíveis para código de pareamento (sem 0, O, 1, I para evitar confusão)
String NetworkManager::generatePairingCode() {
  const char charset[] = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";
  String code = "";
  for (int i = 0; i < 6; i++) {
    int idx = esp_random() % (sizeof(charset) - 1);
    code += charset[idx];
  }
  currentPairCode = code;
  return code;
}

void NetworkManager::onStateChanged(NetworkStateCallback cb) { stateCb = cb; }
void NetworkManager::onPairingCode(PairingCodeCallback cb) { pairingCb = cb; }
void NetworkManager::onPairedSuccess(PairedSuccessCallback cb) { pairedSuccessCb = cb; }
void NetworkManager::onRequestAttended(RequestAttendedCallback cb) { requestAttendedCb = cb; }

bool NetworkManager::isWiFiConnected() {
  return WiFi.status() == WL_CONNECTED;
}

bool NetworkManager::isWsConnected() {
  return currentState == NET_WS_CONNECTED;
}

String NetworkManager::getIP() {
  return WiFi.localIP().toString();
}

void NetworkManager::init() {
  connectWiFi();
}

void NetworkManager::connectWiFi() {
  setState(NET_CONNECTING_WIFI);
  String ssid = StorageManager::getWiFiSSID();
  String pass = StorageManager::getWiFiPass();

  Serial.printf("📶 [WIFI] Conectando a '%s'...\n", ssid.c_str());
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid.c_str(), pass.c_str());

  wifiConnectStartTime = millis();
}

void NetworkManager::startCaptivePortal() {
  portalActive = true;
  setState(NET_AP_PORTAL_ACTIVE);

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);

  IPAddress apIP(192, 168, 4, 1);
  WiFi.softAPConfig(apIP, apIP, IPAddress(255, 255, 255, 0));

  dnsServer.start(53, "*", apIP);

  serverPortal.on("/", HTTP_GET, []() {
    String html = "<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                  "<title>Configurar Wi-Fi</title><style>"
                  "body{font-family:sans-serif;padding:20px;text-align:center;background:#f0f4f8;}"
                  ".card{background:white;padding:25px;border-radius:15px;max-width:340px;margin:auto;box-shadow:0 4px 6px rgba(0,0,0,0.1);}"
                  "input{width:100%;padding:12px;margin:10px 0;border:1px solid #ccc;border-radius:8px;box-sizing:border-box;font-size:16px;}"
                  "button{background:#2563eb;color:white;padding:12px;width:100%;border:none;border-radius:8px;font-size:16px;font-weight:bold;cursor:pointer;}"
                  "</style></head><body><div class='card'>"
                  "<h2>🕒 Relógio Assistivo</h2><p>Configuração de Rede</p>"
                  "<form method='POST' action='/save'>"
                  "<input type='text' name='ssid' placeholder='Nome da Rede Wi-Fi' required>"
                  "<input type='password' name='pass' placeholder='Senha da Rede'>"
                  "<input type='text' name='host' placeholder='IP do Servidor (ex: 192.168.1.100)' value='" + StorageManager::getServerHost() + "'>"
                  "<button type='submit'>Salvar e Reiniciar</button>"
                  "</form></div></body></html>";
    serverPortal.send(200, "text/html", html);
  });

  serverPortal.on("/save", HTTP_POST, []() {
    String newSsid = serverPortal.arg("ssid");
    String newPass = serverPortal.arg("pass");
    String newHost = serverPortal.arg("host");

    if (newSsid.length() > 0) {
      StorageManager::saveWiFi(newSsid, newPass);
      if (newHost.length() > 0) {
        StorageManager::saveServerConfig(newHost, SERVER_PORT);
      }
      serverPortal.send(200, "text/html", "<h2>Configurações salvas com sucesso!</h2><p>O relógio irá reiniciar e conectar à nova rede.</p>");
      delay(1500);
      ESP.restart();
    } else {
      serverPortal.send(400, "text/plain", "SSID inválido.");
    }
  });

  serverPortal.begin();
  Serial.println("🌐 [PORTAL] SoftAP iniciado: 'Relogio-Assistivo' (IP: 192.168.4.1)");
}

static void onWsEvent(WStype_t type, uint8_t *payload, size_t length) {
  switch (type) {
    case WStype_DISCONNECTED:
      Serial.println("📡 [WS] Desconectado do servidor.");
      setState(NET_WS_DISCONNECTED);
      break;

    case WStype_CONNECTED:
      Serial.println("📡 [WS] Conectado ao servidor!");
      setState(NET_WS_CONNECTED);
      NetworkManager::checkPairingStatus();
      break;

    case WStype_TEXT: {
      StaticJsonDocument<512> doc;
      DeserializationError err = deserializeJson(doc, payload, length);
      if (err) {
        Serial.print("Erro no parse JSON do WS: ");
        Serial.println(err.c_str());
        return;
      }

      const char *event = doc["event"];
      if (!event) return;

      if (strcmp(event, "PAIRED") == 0) {
        const char *token = doc["token"];
        const char *user = doc["user_name"];
        Serial.printf("🎉 [WS] Pareamento confirmado! Usuário: %s\n", user);
        StorageManager::savePairing(token ? token : "ok", user ? user : "João");
        if (pairedSuccessCb) {
          pairedSuccessCb(user ? user : "João");
        }
      } else if (strcmp(event, "REQUEST_ATTENDED") == 0) {
        const char *lbl = doc["label"] | "Solicitação";
        const char *msg = doc["message"] | "Pedido atendido!";
        Serial.printf("❤️ [WS] Pedido atendido pelo responsável: %s\n", lbl);
        if (requestAttendedCb) {
          requestAttendedCb(lbl, msg);
        }
      }
      break;
    }
    default:
      break;
  }
}

void NetworkManager::checkPairingStatus() {
  if (StorageManager::isPaired()) {
    // Já está pareado, envia autenticação
    StaticJsonDocument<256> doc;
    doc["action"] = "AUTH";
    doc["device_id"] = StorageManager::getDeviceId();
    doc["token"] = StorageManager::getPairedToken();
    doc["battery"] = BatteryMonitor::getPercentage();
    doc["voltage"] = BatteryMonitor::getVoltage();

    String json;
    serializeJson(doc, json);
    webSocket.sendTXT(json);
  } else {
    // Não está pareado, gera código de pareamento e registra no servidor
    String code = generatePairingCode();
    sendPairingCode(code);
    if (pairingCb) {
      pairingCb(code);
    }
  }
}

void NetworkManager::sendPairingCode(const String &code) {
  StaticJsonDocument<256> doc;
  doc["action"] = "REGISTER_PAIR_CODE";
  doc["device_id"] = StorageManager::getDeviceId();
  doc["code"] = code;

  String json;
  serializeJson(doc, json);
  webSocket.sendTXT(json);
  Serial.printf("🔑 [PAREAMENTO] Código %s registrado no servidor para %s\n", code.c_str(), StorageManager::getDeviceId().c_str());
}

void NetworkManager::sendAssistiveRequest(const String &category, const String &label, const String &details, const String &priority) {
  if (currentState != NET_WS_CONNECTED) {
    Serial.println("⚠️ Não foi possível enviar: WebSocket não conectado.");
    return;
  }

  StaticJsonDocument<384> doc;
  doc["type"] = "REQUEST";
  doc["device_id"] = StorageManager::getDeviceId();
  doc["category"] = category;
  doc["label"] = label;
  doc["details"] = details;
  doc["priority"] = priority;
  doc["battery"] = BatteryMonitor::getPercentage();
  doc["voltage"] = BatteryMonitor::getVoltage();

  String json;
  serializeJson(doc, json);
  webSocket.sendTXT(json);
  Serial.printf("🚨 [ENVIO] Pedido enviado: %s (%s)\n", label.c_str(), priority.c_str());
}

void NetworkManager::sendHeartbeat() {
  if (currentState == NET_WS_CONNECTED) {
    StaticJsonDocument<256> doc;
    doc["action"] = "HEARTBEAT";
    doc["device_id"] = StorageManager::getDeviceId();
    doc["battery"] = BatteryMonitor::getPercentage();
    doc["voltage"] = BatteryMonitor::getVoltage();

    String json;
    serializeJson(doc, json);
    webSocket.sendTXT(json);
  }
}

void NetworkManager::loop() {
  // Trata SoftAP / Captive Portal se ativo
  if (portalActive) {
    dnsServer.processNextRequest();
    serverPortal.handleClient();
    return;
  }

  // Verifica conexão Wi-Fi
  if (WiFi.status() == WL_CONNECTED) {
    if (currentState == NET_CONNECTING_WIFI) {
      Serial.print("✅ [WIFI] Conectado! IP: ");
      Serial.println(WiFi.localIP());
      setState(NET_CONNECTED_WIFI);

      // Inicia WebSocket
      String host = StorageManager::getServerHost();
      uint16_t port = StorageManager::getServerPort();
      Serial.printf("🔌 [WS] Conectando a ws://%s:%d%s\n", host.c_str(), port, WS_PATH);

      webSocket.begin(host.c_str(), port, WS_PATH);
      webSocket.onEvent(onWsEvent);
      webSocket.setReconnectInterval(5000);
    }

    webSocket.loop();

    // Envio periódico de Heartbeat/Telemetria
    if (millis() - lastHeartbeatTime > HEARTBEAT_INTERVAL_MS) {
      lastHeartbeatTime = millis();
      sendHeartbeat();
    }
  } else {
    // Timeout de conexão com Wi-Fi (15 segundos) -> entra em modo AP Portal
    if (currentState == NET_CONNECTING_WIFI && (millis() - wifiConnectStartTime > 15000)) {
      Serial.println("❌ [WIFI] Falha ao conectar. Iniciando SoftAP de configuração...");
      startCaptivePortal();
    }
  }
}
