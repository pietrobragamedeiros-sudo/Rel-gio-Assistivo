#include "battery_monitor.h"

float BatteryMonitor::currentVoltage = 4.10f;
uint8_t BatteryMonitor::currentPercentage = 90;

void BatteryMonitor::init() {
  pinMode(PIN_BAT_ADC, INPUT);
  analogReadResolution(12); // 12 bits (0-4095)
  analogSetAttenuation(ADC_11db); // Permite ler tensões até ~3.3V no pino
  update();
}

void BatteryMonitor::update() {
  uint32_t sum = 0;
  const int samples = 16;
  for (int i = 0; i < samples; i++) {
    sum += analogRead(PIN_BAT_ADC);
    delayMicroseconds(50);
  }
  float rawAdc = (float)sum / samples;

  // Converte ADC para tensão no pino (considerando Vref ~3.3V)
  float pinVoltage = (rawAdc / 4095.0f) * 3.3f;

  // Tensão real da bateria considerando o divisor 2:1
  float batteryVoltage = pinVoltage * BAT_DIVIDER_RATIO;

  // Calibração e limites
  if (batteryVoltage > 4.25f) batteryVoltage = 4.20f;
  if (batteryVoltage < 3.00f) batteryVoltage = 3.30f;

  currentVoltage = batteryVoltage;

  // Cálculo da porcentagem (curva linear aproximada)
  float pct = ((batteryVoltage - BAT_VOLTAGE_MIN) / (BAT_VOLTAGE_MAX - BAT_VOLTAGE_MIN)) * 100.0f;
  if (pct > 100.0f) pct = 100.0f;
  if (pct < 0.0f) pct = 0.0f;

  currentPercentage = (uint8_t)pct;
}

float BatteryMonitor::getVoltage() {
  return currentVoltage;
}

uint8_t BatteryMonitor::getPercentage() {
  return currentPercentage;
}

bool BatteryMonitor::isCharging() {
  return currentVoltage >= 4.18f;
}
