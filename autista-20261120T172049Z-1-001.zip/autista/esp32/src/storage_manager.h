#pragma once

#include <Arduino.h>
#include <Preferences.h>
#include "../include/config.h"

class StorageManager {
public:
  static void init();
  static String getDeviceId();

  // Wi-Fi
  static String getWiFiSSID();
  static String getWiFiPass();
  static void saveWiFi(const String &ssid, const String &pass);
  static bool hasSavedWiFi();

  // Servidor
  static String getServerHost();
  static uint16_t getServerPort();
  static void saveServerConfig(const String &host, uint16_t port);

  // Pareamento
  static bool isPaired();
  static String getPairedToken();
  static String getUserName();
  static void savePairing(const String &token, const String &userName);
  static void clearPairing();

  // Configurações gerais
  static uint8_t getBrightness();
  static void saveBrightness(uint8_t val);

private:
  static Preferences prefs;
  static String cachedDeviceId;
};
