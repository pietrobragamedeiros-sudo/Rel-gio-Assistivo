#pragma once

#include <Arduino.h>
#include "../include/config.h"

class BatteryMonitor {
public:
  static void init();
  static void update();
  static float getVoltage();
  static uint8_t getPercentage();
  static bool isCharging();

private:
  static float currentVoltage;
  static uint8_t currentPercentage;
};
