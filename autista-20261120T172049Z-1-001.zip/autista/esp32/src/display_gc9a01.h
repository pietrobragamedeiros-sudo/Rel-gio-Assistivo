#pragma once

#include <Arduino.h>
#include <SPI.h>
#include <lvgl.h>
#include "../include/config.h"

class DisplayGC9A01 {
public:
  static void init();
  static void setBrightness(uint8_t percentage); // 0 a 100%
  static void setAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);
  static void pushColors(uint16_t *data, uint32_t len);

  // Callbacks para LVGL
#if LVGL_VERSION_MAJOR >= 9
  static void flushCallback(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map);
#else
  static void flushCallback(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p);
#endif

private:
  static void sendCommand(uint8_t cmd);
  static void sendData(uint8_t data);
  static void sendDataBytes(const uint8_t *data, size_t len);
  static void hardwareReset();
  static void initCommands();
};
