#include "ui_manager.h"
#include "network_manager.h"
#include "storage_manager.h"
#include "battery_monitor.h"

// Compatibilidade de API LVGL 8 / LVGL 9
#if LVGL_VERSION_MAJOR >= 9
  #define SCREEN_LOAD(s) lv_screen_load(s)
#else
  #define SCREEN_LOAD(s) lv_scr_load(s)
#endif

// Telas LVGL
static lv_obj_t * scrBoot = nullptr;
static lv_obj_t * scrPairing = nullptr;
static lv_obj_t * scrConnected = nullptr;
static lv_obj_t * scrMain = nullptr;
static lv_obj_t * scrMore = nullptr;
static lv_obj_t * scrConfirm = nullptr;
static lv_obj_t * scrSosConfirm = nullptr;
static lv_obj_t * scrPainSelect = nullptr;
static lv_obj_t * scrSent = nullptr;
static lv_obj_t * scrAttended = nullptr;

// Widgets Dinâmicos
static lv_obj_t * lblBootStatus = nullptr;
static lv_obj_t * lblPairCode = nullptr;
static lv_obj_t * lblConnectedUser = nullptr;
static lv_obj_t * lblMainBattery = nullptr;
static lv_obj_t * lblConfirmQuestion = nullptr;
static lv_obj_t * lblAttendedMsg = nullptr;

// Dados da Solicitação Atual para Confirmação
static String currentReqCat = "";
static String currentReqLabel = "";
static String currentReqDetails = "";
static String currentReqPriority = "NORMAL";

// Forward declarations
static void btnNeedClickHandler(lv_event_t * e);
static void btnConfirmYesHandler(lv_event_t * e);
static void btnConfirmNoHandler(lv_event_t * e);
static void btnPainPartHandler(lv_event_t * e);
static void btnRefreshCodeHandler(lv_event_t * e);

void UIManager::init() {
  createStyles();

  buildBootScreen();
  buildPairingScreen();
  buildConnectedScreen();
  buildMainScreen();
  buildMoreScreen();
  buildConfirmScreen();
  buildSosConfirmScreen();
  buildPainSelectScreen();
  buildSentScreen();
  buildAttendedScreen();

  showScreen(SCREEN_BOOT);
}

void UIManager::createStyles() {
  // Configuração global de fontes e cores
}

void UIManager::showScreen(UIScreen screen) {
  switch (screen) {
    case SCREEN_BOOT:        SCREEN_LOAD(scrBoot); break;
    case SCREEN_PAIRING:     SCREEN_LOAD(scrPairing); break;
    case SCREEN_CONNECTED:   SCREEN_LOAD(scrConnected); break;
    case SCREEN_MAIN:        SCREEN_LOAD(scrMain); break;
    case SCREEN_MORE:        SCREEN_LOAD(scrMore); break;
    case SCREEN_CONFIRM:     SCREEN_LOAD(scrConfirm); break;
    case SCREEN_SOS_CONFIRM: SCREEN_LOAD(scrSosConfirm); break;
    case SCREEN_PAIN_SELECT: SCREEN_LOAD(scrPainSelect); break;
    case SCREEN_SENT:        SCREEN_LOAD(scrSent); break;
    case SCREEN_ATTENDED:    SCREEN_LOAD(scrAttended); break;
  }
}

// -----------------------------------------------------------------
// 1. TELA DE INICIALIZAÇÃO (BOOT)
// -----------------------------------------------------------------
void UIManager::buildBootScreen() {
  scrBoot = lv_obj_create(NULL);
  lv_obj_set_style_bg_color(scrBoot, lv_color_hex(0x0f172a), LV_PART_MAIN);

  lv_obj_t * lblTitle = lv_label_create(scrBoot);
  lv_label_set_text(lblTitle, "Relogio Assistivo");
  lv_obj_set_style_text_color(lblTitle, lv_color_hex(0x38bdf8), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblTitle, &lv_font_montserrat_18, LV_PART_MAIN);
  lv_obj_align(lblTitle, LV_ALIGN_CENTER, 0, -35);

  lblBootStatus = lv_label_create(scrBoot);
  lv_label_set_text(lblBootStatus, "Iniciando...");
  lv_obj_set_style_text_color(lblBootStatus, lv_color_hex(0x94a3b8), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblBootStatus, &lv_font_montserrat_14, LV_PART_MAIN);
  lv_obj_align(lblBootStatus, LV_ALIGN_CENTER, 0, 15);
}

void UIManager::setStatusMessage(const String &msg) {
  if (lblBootStatus) {
    lv_label_set_text(lblBootStatus, msg.c_str());
  }
}

// -----------------------------------------------------------------
// 2. TELA DE PAREAMENTO (CÓDIGO TEMPORÁRIO)
// -----------------------------------------------------------------
void UIManager::buildPairingScreen() {
  scrPairing = lv_obj_create(NULL);
  lv_obj_set_style_bg_color(scrPairing, lv_color_hex(0x0f172a), LV_PART_MAIN);

  lv_obj_t * lblTitle = lv_label_create(scrPairing);
  lv_label_set_text(lblTitle, "Conectar Relogio");
  lv_obj_set_style_text_color(lblPairing, lv_color_hex(0xffffff), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblTitle, &lv_font_montserrat_14, LV_PART_MAIN);
  lv_obj_align(lblTitle, LV_ALIGN_TOP_MID, 0, 20);

  // Cartão com o código de 6 caracteres
  lv_obj_t * card = lv_obj_create(scrPairing);
  lv_obj_set_size(card, 180, 60);
  lv_obj_set_style_bg_color(card, lv_color_hex(0x1e293b), LV_PART_MAIN);
  lv_obj_set_style_border_color(card, lv_color_hex(0x38bdf8), LV_PART_MAIN);
  lv_obj_set_style_border_width(card, 2, LV_PART_MAIN);
  lv_obj_set_style_radius(card, 12, LV_PART_MAIN);
  lv_obj_align(card, LV_ALIGN_CENTER, 0, -10);

  lblPairCode = lv_label_create(card);
  lv_label_set_text(lblPairCode, "------");
  lv_obj_set_style_text_color(lblPairCode, lv_color_hex(0x38bdf8), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblPairCode, &lv_font_montserrat_24, LV_PART_MAIN);
  lv_obj_align(lblPairCode, LV_ALIGN_CENTER, 0, 0);

  lv_obj_t * lblSub = lv_label_create(scrPairing);
  lv_label_set_text(lblSub, "Digite o codigo no site");
  lv_obj_set_style_text_color(lblSub, lv_color_hex(0x94a3b8), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblSub, &lv_font_montserrat_12, LV_PART_MAIN);
  lv_obj_align(lblSub, LV_ALIGN_CENTER, 0, 40);

  // Botão Atualizar Código
  lv_obj_t * btnRefresh = lv_btn_create(scrPairing);
  lv_obj_set_size(btnRefresh, 140, 32);
  lv_obj_set_style_bg_color(btnRefresh, lv_color_hex(0x334155), LV_PART_MAIN);
  lv_obj_set_style_radius(btnRefresh, 16, LV_PART_MAIN);
  lv_obj_align(btnRefresh, LV_ALIGN_BOTTOM_MID, 0, -15);
  lv_obj_add_event_cb(btnRefresh, btnRefreshCodeHandler, LV_EVENT_CLICKED, NULL);

  lv_obj_t * lblBtn = lv_label_create(btnRefresh);
  lv_label_set_text(lblBtn, "Novo Codigo");
  lv_obj_set_style_text_font(lblBtn, &lv_font_montserrat_12, LV_PART_MAIN);
  lv_obj_align(lblBtn, LV_ALIGN_CENTER, 0, 0);
}

void UIManager::setPairingCode(const String &code) {
  if (lblPairCode) {
    lv_label_set_text(lblPairCode, code.c_str());
  }
}

static void btnRefreshCodeHandler(lv_event_t * e) {
  String newCode = NetworkManager::generatePairingCode();
  UIManager::setPairingCode(newCode);
  NetworkManager::sendPairingCode(newCode);
}

// -----------------------------------------------------------------
// 3. TELA DE SUCESSO DE PAREAMENTO (CONECTADO)
// -----------------------------------------------------------------
void UIManager::buildConnectedScreen() {
  scrConnected = lv_obj_create(NULL);
  lv_obj_set_style_bg_color(scrConnected, lv_color_hex(0x064e3b), LV_PART_MAIN);

  lv_obj_t * lblCheck = lv_label_create(scrConnected);
  lv_label_set_text(lblCheck, "OK");
  lv_obj_set_style_text_color(lblCheck, lv_color_hex(0x34d399), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblCheck, &lv_font_montserrat_28, LV_PART_MAIN);
  lv_obj_align(lblCheck, LV_ALIGN_CENTER, 0, -40);

  lv_obj_t * lblTitle = lv_label_create(scrConnected);
  lv_label_set_text(lblTitle, "Relogio Conectado!");
  lv_obj_set_style_text_color(lblTitle, lv_color_hex(0xffffff), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblTitle, &lv_font_montserrat_16, LV_PART_MAIN);
  lv_obj_align(lblTitle, LV_ALIGN_CENTER, 0, 0);

  lblConnectedUser = lv_label_create(scrConnected);
  lv_label_set_text(lblConnectedUser, "Ola!");
  lv_obj_set_style_text_color(lblConnectedUser, lv_color_hex(0xa7f3d0), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblConnectedUser, &lv_font_montserrat_14, LV_PART_MAIN);
  lv_obj_align(lblConnectedUser, LV_ALIGN_CENTER, 0, 30);
}

void UIManager::setUserName(const String &name) {
  if (lblConnectedUser) {
    String msg = "Ola, " + name + "!";
    lv_label_set_text(lblConnectedUser, msg.c_str());
  }
}

// -----------------------------------------------------------------
// 4. TELA PRINCIPAL (CARROSSEL DE NECESSIDADES BÁSICAS)
// -----------------------------------------------------------------
static lv_obj_t* createNeedButton(lv_obj_t *parent, const char* label, uint32_t colorHex, const char* catCode) {
  lv_obj_t * btn = lv_btn_create(parent);
  lv_obj_set_size(btn, 190, 48);
  lv_obj_set_style_bg_color(btn, lv_color_hex(colorHex), LV_PART_MAIN);
  lv_obj_set_style_radius(btn, 24, LV_PART_MAIN);
  lv_obj_set_style_shadow_width(btn, 6, LV_PART_MAIN);
  lv_obj_set_style_shadow_color(btn, lv_color_hex(0x000000), LV_PART_MAIN);
  lv_obj_set_style_shadow_opa(btn, LV_OPA_30, LV_PART_MAIN);

  lv_obj_t * lbl = lv_label_create(btn);
  lv_label_set_text(lbl, label);
  lv_obj_set_style_text_font(lbl, &lv_font_montserrat_18, LV_PART_MAIN);
  lv_obj_set_style_text_color(lbl, lv_color_hex(0xffffff), LV_PART_MAIN);
  lv_obj_align(lbl, LV_ALIGN_CENTER, 0, 0);

  // Armazena categoria no user_data do botão
  lv_obj_set_user_data(btn, (void*)catCode);
  lv_obj_add_event_cb(btn, btnNeedClickHandler, LV_EVENT_CLICKED, NULL);

  return btn;
}

void UIManager::buildMainScreen() {
  scrMain = lv_obj_create(NULL);
  lv_obj_set_style_bg_color(scrMain, lv_color_hex(0x0f172a), LV_PART_MAIN);

  // Top Bar (Bateria)
  lblMainBattery = lv_label_create(scrMain);
  lv_label_set_text(lblMainBattery, "85%");
  lv_obj_set_style_text_color(lblMainBattery, lv_color_hex(0x38bdf8), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblMainBattery, &lv_font_montserrat_12, LV_PART_MAIN);
  lv_obj_align(lblMainBattery, LV_ALIGN_TOP_MID, 0, 8);

  // Container vertical com rolagem suave para tela circular de 1.28"
  lv_obj_t * cont = lv_obj_create(scrMain);
  lv_obj_set_size(cont, 220, 185);
  lv_obj_align(cont, LV_ALIGN_CENTER, 0, 12);
  lv_obj_set_flex_flow(cont, LV_FLEX_FLOW_COLUMN);
  lv_obj_set_flex_align(cont, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
  lv_obj_set_style_bg_opa(cont, LV_OPA_TRANSP, LV_PART_MAIN);
  lv_obj_set_style_border_width(cont, 0, LV_PART_MAIN);
  lv_obj_set_style_pad_row(cont, 10, LV_PART_MAIN);
  lv_obj_set_style_pad_top(cont, 5, LV_PART_MAIN);
  lv_obj_set_style_pad_bottom(cont, 30, LV_PART_MAIN);

  // Botões principais com alto contraste
  createNeedButton(cont, "AGUA",     0x2563eb, "AGUA");
  createNeedButton(cont, "COMER",    0xd97706, "COMER");
  createNeedButton(cont, "BANHEIRO", 0x0d9488, "BANHEIRO");
  createNeedButton(cont, "DORMIR",   0x4f46e5, "DORMIR");
  createNeedButton(cont, "BRINCAR",  0x16a34a, "BRINCAR");
  createNeedButton(cont, "AJUDA",    0xdc2626, "AJUDA"); // SOS em vermelho
  createNeedButton(cont, "DOR",      0xb45309, "DOR");   // Dor em âmbar
  createNeedButton(cont, "MAIS...",  0x475569, "MAIS");  // Outras opções
}

static void btnNeedClickHandler(lv_event_t * e) {
  lv_obj_t * btn = (lv_obj_t *)lv_event_get_target(e);
  const char* code = (const char*)lv_obj_get_user_data(btn);
  if (!code) return;

  String cat = String(code);

  if (cat == "AJUDA") {
    UIManager::showScreen(SCREEN_SOS_CONFIRM);
    return;
  }
  if (cat == "DOR") {
    UIManager::showScreen(SCREEN_PAIN_SELECT);
    return;
  }
  if (cat == "MAIS") {
    UIManager::showScreen(SCREEN_MORE);
    return;
  }

  // Prepara confirmação simples
  if (cat == "AGUA") {
    UIManager::prepareConfirmation("AGUA", "Beber agua", "Quer agua?");
  } else if (cat == "COMER") {
    UIManager::prepareConfirmation("COMER", "Comer", "Quer comer?");
  } else if (cat == "BANHEIRO") {
    UIManager::prepareConfirmation("BANHEIRO", "Banheiro", "Quer ir ao banheiro?");
  } else if (cat == "DORMIR") {
    UIManager::prepareConfirmation("DORMIR", "Dormir", "Quer dormir?");
  } else if (cat == "BRINCAR") {
    UIManager::prepareConfirmation("BRINCAR", "Brincar", "Quer brincar?");
  } else if (cat == "REMEDIO") {
    UIManager::prepareConfirmation("REMEDIO", "Tomar remedio", "Quer o remedio?");
  } else if (cat == "CANSADO") {
    UIManager::prepareConfirmation("CANSADO", "Estou cansado", "Esta cansado?");
  } else if (cat == "SAIR") {
    UIManager::prepareConfirmation("SAIR", "Quero sair", "Quer passear/sair?");
  } else if (cat == "MAE") {
    UIManager::prepareConfirmation("MAE", "Chamar mae", "Chamar a mamae?");
  } else if (cat == "PAI") {
    UIManager::prepareConfirmation("PAI", "Chamar pai", "Chamar o papai?");
  } else {
    UIManager::prepareConfirmation("OUTRO", "Preciso de ajuda", "Quer ajuda?");
  }

  UIManager::showScreen(SCREEN_CONFIRM);
}

// -----------------------------------------------------------------
// 5. SUBMENU DE OUTRAS OPÇÕES
// -----------------------------------------------------------------
void UIManager::buildMoreScreen() {
  scrMore = lv_obj_create(NULL);
  lv_obj_set_style_bg_color(scrMore, lv_color_hex(0x0f172a), LV_PART_MAIN);

  lv_obj_t * lblTitle = lv_label_create(scrMore);
  lv_label_set_text(lblTitle, "Mais Opcoes");
  lv_obj_set_style_text_color(lblTitle, lv_color_hex(0xffffff), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblTitle, &lv_font_montserrat_12, LV_PART_MAIN);
  lv_obj_align(lblTitle, LV_ALIGN_TOP_MID, 0, 8);

  lv_obj_t * cont = lv_obj_create(scrMore);
  lv_obj_set_size(cont, 220, 185);
  lv_obj_align(cont, LV_ALIGN_CENTER, 0, 12);
  lv_obj_set_flex_flow(cont, LV_FLEX_FLOW_COLUMN);
  lv_obj_set_flex_align(cont, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
  lv_obj_set_style_bg_opa(cont, LV_OPA_TRANSP, LV_PART_MAIN);
  lv_obj_set_style_border_width(cont, 0, LV_PART_MAIN);
  lv_obj_set_style_pad_row(cont, 10, LV_PART_MAIN);
  lv_obj_set_style_pad_bottom(cont, 30, LV_PART_MAIN);

  createNeedButton(cont, "REMEDIO",  0x7c3aed, "REMEDIO");
  createNeedButton(cont, "CANSADO",  0x0284c7, "CANSADO");
  createNeedButton(cont, "SAIR",     0x059669, "SAIR");
  createNeedButton(cont, "MAMAE",    0xdb2777, "MAE");
  createNeedButton(cont, "PAPAI",    0x2563eb, "PAI");
  createNeedButton(cont, "VOLTAR",   0x334155, "VOLTAR_MAIN");

  // Handler para voltar
  lv_obj_t * btnVoltar = lv_obj_get_child(cont, -1);
  lv_obj_add_event_cb(btnVoltar, [](lv_event_t * e) {
    UIManager::showScreen(SCREEN_MAIN);
  }, LV_EVENT_CLICKED, NULL);
}

// -----------------------------------------------------------------
// 6. TELA DE CONFIRMAÇÃO DE TOQUE ("SIM" / "NÃO")
// -----------------------------------------------------------------
void UIManager::buildConfirmScreen() {
  scrConfirm = lv_obj_create(NULL);
  lv_obj_set_style_bg_color(scrConfirm, lv_color_hex(0x0f172a), LV_PART_MAIN);

  lblConfirmQuestion = lv_label_create(scrConfirm);
  lv_label_set_text(lblConfirmQuestion, "Quer agua?");
  lv_obj_set_style_text_color(lblConfirmQuestion, lv_color_hex(0xffffff), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblConfirmQuestion, &lv_font_montserrat_18, LV_PART_MAIN);
  lv_obj_align(lblConfirmQuestion, LV_ALIGN_CENTER, 0, -40);

  // Botão SIM (Verde)
  lv_obj_t * btnSim = lv_btn_create(scrConfirm);
  lv_obj_set_size(btnSim, 180, 48);
  lv_obj_set_style_bg_color(btnSim, lv_color_hex(0x16a34a), LV_PART_MAIN);
  lv_obj_set_style_radius(btnSim, 24, LV_PART_MAIN);
  lv_obj_align(btnSim, LV_ALIGN_CENTER, 0, 10);
  lv_obj_add_event_cb(btnSim, btnConfirmYesHandler, LV_EVENT_CLICKED, NULL);

  lv_obj_t * lblSim = lv_label_create(btnSim);
  lv_label_set_text(lblSim, "SIM");
  lv_obj_set_style_text_font(lblSim, &lv_font_montserrat_20, LV_PART_MAIN);
  lv_obj_align(lblSim, LV_ALIGN_CENTER, 0, 0);

  // Botão NÃO (Vermelho / Cancelar)
  lv_obj_t * btnNao = lv_btn_create(scrConfirm);
  lv_obj_set_size(btnNao, 140, 36);
  lv_obj_set_style_bg_color(btnNao, lv_color_hex(0xdc2626), LV_PART_MAIN);
  lv_obj_set_style_radius(btnNao, 18, LV_PART_MAIN);
  lv_obj_align(btnNao, LV_ALIGN_CENTER, 0, 65);
  lv_obj_add_event_cb(btnNao, btnConfirmNoHandler, LV_EVENT_CLICKED, NULL);

  lv_obj_t * lblNao = lv_label_create(btnNao);
  lv_label_set_text(lblNao, "NAO");
  lv_obj_set_style_text_font(lblNao, &lv_font_montserrat_16, LV_PART_MAIN);
  lv_obj_align(lblNao, LV_ALIGN_CENTER, 0, 0);
}

void UIManager::prepareConfirmation(const String &cat, const String &label, const String &question, const String &prio) {
  currentReqCat = cat;
  currentReqLabel = label;
  currentReqDetails = question;
  currentReqPriority = prio;

  if (lblConfirmQuestion) {
    lv_label_set_text(lblConfirmQuestion, question.c_str());
  }
}

static void btnConfirmYesHandler(lv_event_t * e) {
  UIManager::confirmAndSendCurrent();
}

static void btnConfirmNoHandler(lv_event_t * e) {
  UIManager::showScreen(SCREEN_MAIN);
}

void UIManager::confirmAndSendCurrent() {
  NetworkManager::sendAssistiveRequest(currentReqCat, currentReqLabel, currentReqDetails, currentReqPriority);
  showScreen(SCREEN_SENT);

  // Retorna automaticamente à tela principal após 3.5 segundos
  lv_timer_t * timer = lv_timer_create([](lv_timer_t * t) {
    UIManager::showScreen(SCREEN_MAIN);
    lv_timer_del(t);
  }, 3500, NULL);
}

// -----------------------------------------------------------------
// 7. TELA DE CONFIRMAÇÃO DE EMERGÊNCIA (SOS)
// -----------------------------------------------------------------
void UIManager::buildSosConfirmScreen() {
  scrSosConfirm = lv_obj_create(NULL);
  lv_obj_set_style_bg_color(scrSosConfirm, lv_color_hex(0x450a0a), LV_PART_MAIN); // Fundo vermelho escuro

  lv_obj_t * lblSos = lv_label_create(scrSosConfirm);
  lv_label_set_text(lblSos, "AJUDA!");
  lv_obj_set_style_text_color(lblSos, lv_color_hex(0xf87171), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblSos, &lv_font_montserrat_24, LV_PART_MAIN);
  lv_obj_align(lblSos, LV_ALIGN_CENTER, 0, -45);

  lv_obj_t * lblSub = lv_label_create(scrSosConfirm);
  lv_label_set_text(lblSub, "Precisa de ajuda?");
  lv_obj_set_style_text_color(lblSub, lv_color_hex(0xffffff), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblSub, &lv_font_montserrat_14, LV_PART_MAIN);
  lv_obj_align(lblSub, LV_ALIGN_CENTER, 0, -15);

  lv_obj_t * btnSim = lv_btn_create(scrSosConfirm);
  lv_obj_set_size(btnSim, 180, 48);
  lv_obj_set_style_bg_color(btnSim, lv_color_hex(0xdc2626), LV_PART_MAIN);
  lv_obj_set_style_radius(btnSim, 24, LV_PART_MAIN);
  lv_obj_align(btnSim, LV_ALIGN_CENTER, 0, 25);
  lv_obj_add_event_cb(btnSim, [](lv_event_t * e) {
    currentReqCat = "AJUDA";
    currentReqLabel = "PEDIDO DE AJUDA";
    currentReqDetails = "O usuario solicitou ajuda urgente no relogio";
    currentReqPriority = "EMERGENCIA";
    UIManager::confirmAndSendCurrent();
  }, LV_EVENT_CLICKED, NULL);

  lv_obj_t * lblBtnSim = lv_label_create(btnSim);
  lv_label_set_text(lblBtnSim, "SIM, PRECISO");
  lv_obj_set_style_text_font(lblBtnSim, &lv_font_montserrat_16, LV_PART_MAIN);
  lv_obj_align(lblBtnSim, LV_ALIGN_CENTER, 0, 0);

  lv_obj_t * btnNao = lv_btn_create(scrSosConfirm);
  lv_obj_set_size(btnNao, 120, 32);
  lv_obj_set_style_bg_color(btnNao, lv_color_hex(0x7f1d1d), LV_PART_MAIN);
  lv_obj_set_style_radius(btnNao, 16, LV_PART_MAIN);
  lv_obj_align(btnNao, LV_ALIGN_CENTER, 0, 75);
  lv_obj_add_event_cb(btnNao, [](lv_event_t * e) {
    UIManager::showScreen(SCREEN_MAIN);
  }, LV_EVENT_CLICKED, NULL);

  lv_obj_t * lblBtnNao = lv_label_create(btnNao);
  lv_label_set_text(lblBtnNao, "CANCELAR");
  lv_obj_set_style_text_font(lblBtnNao, &lv_font_montserrat_12, LV_PART_MAIN);
  lv_obj_align(lblBtnNao, LV_ALIGN_CENTER, 0, 0);
}

// -----------------------------------------------------------------
// 8. TELA DE LOCAL DA DOR ("ONDE DÓI?")
// -----------------------------------------------------------------
void UIManager::buildPainSelectScreen() {
  scrPainSelect = lv_obj_create(NULL);
  lv_obj_set_style_bg_color(scrPainSelect, lv_color_hex(0x0f172a), LV_PART_MAIN);

  lv_obj_t * lblTitle = lv_label_create(scrPainSelect);
  lv_label_set_text(lblTitle, "Onde doi?");
  lv_obj_set_style_text_color(lblTitle, lv_color_hex(0xfbbf24), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblTitle, &lv_font_montserrat_16, LV_PART_MAIN);
  lv_obj_align(lblTitle, LV_ALIGN_TOP_MID, 0, 10);

  lv_obj_t * cont = lv_obj_create(scrPainSelect);
  lv_obj_set_size(cont, 220, 185);
  lv_obj_align(cont, LV_ALIGN_CENTER, 0, 15);
  lv_obj_set_flex_flow(cont, LV_FLEX_FLOW_COLUMN);
  lv_obj_set_flex_align(cont, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
  lv_obj_set_style_bg_opa(cont, LV_OPA_TRANSP, LV_PART_MAIN);
  lv_obj_set_style_border_width(cont, 0, LV_PART_MAIN);
  lv_obj_set_style_pad_row(cont, 8, LV_PART_MAIN);
  lv_obj_set_style_pad_bottom(cont, 30, LV_PART_MAIN);

  const char* parts[] = { "Cabeca", "Barriga", "Peito", "Braco", "Perna", "Outro" };
  for (int i = 0; i < 6; i++) {
    lv_obj_t * btn = lv_btn_create(cont);
    lv_obj_set_size(btn, 170, 42);
    lv_obj_set_style_bg_color(btn, lv_color_hex(0x78350f), LV_PART_MAIN);
    lv_obj_set_style_radius(btn, 21, LV_PART_MAIN);

    lv_obj_t * lbl = lv_label_create(btn);
    lv_label_set_text(lbl, parts[i]);
    lv_obj_set_style_text_font(lbl, &lv_font_montserrat_16, LV_PART_MAIN);
    lv_obj_align(lbl, LV_ALIGN_CENTER, 0, 0);

    lv_obj_set_user_data(btn, (void*)parts[i]);
    lv_obj_add_event_cb(btn, btnPainPartHandler, LV_EVENT_CLICKED, NULL);
  }
}

static void btnPainPartHandler(lv_event_t * e) {
  lv_obj_t * btn = (lv_obj_t *)lv_event_get_target(e);
  const char* part = (const char*)lv_obj_get_user_data(btn);
  if (!part) return;

  UIManager::prepareConfirmation("DOR", "Estou com dor", "Dor na " + String(part) + "?", "ALTA");
  currentReqDetails = "Local da dor: " + String(part);
  UIManager::showScreen(SCREEN_CONFIRM);
}

// -----------------------------------------------------------------
// 9. TELA DE PEDIDO ENVIADO
// -----------------------------------------------------------------
void UIManager::buildSentScreen() {
  scrSent = lv_obj_create(NULL);
  lv_obj_set_style_bg_color(scrSent, lv_color_hex(0x0f172a), LV_PART_MAIN);

  lv_obj_t * lblCheck = lv_label_create(scrSent);
  lv_label_set_text(lblCheck, "V");
  lv_obj_set_style_text_color(lblCheck, lv_color_hex(0x22c55e), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblCheck, &lv_font_montserrat_28, LV_PART_MAIN);
  lv_obj_align(lblCheck, LV_ALIGN_CENTER, 0, -35);

  lv_obj_t * lblTitle = lv_label_create(scrSent);
  lv_label_set_text(lblTitle, "Pedido Enviado!");
  lv_obj_set_style_text_color(lblTitle, lv_color_hex(0xffffff), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblTitle, &lv_font_montserrat_18, LV_PART_MAIN);
  lv_obj_align(lblTitle, LV_ALIGN_CENTER, 0, 5);

  lv_obj_t * lblSub = lv_label_create(scrSent);
  lv_label_set_text(lblSub, "Aguarde o responsavel");
  lv_obj_set_style_text_color(lblSub, lv_color_hex(0x94a3b8), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblSub, &lv_font_montserrat_12, LV_PART_MAIN);
  lv_obj_align(lblSub, LV_ALIGN_CENTER, 0, 35);
}

// -----------------------------------------------------------------
// 10. TELA DE PEDIDO ATENDIDO (CONFIRMAÇÃO DO RESPONSÁVEL)
// -----------------------------------------------------------------
void UIManager::buildAttendedScreen() {
  scrAttended = lv_obj_create(NULL);
  lv_obj_set_style_bg_color(scrAttended, lv_color_hex(0x064e3b), LV_PART_MAIN); // Fundo verde

  lv_obj_t * lblHeart = lv_label_create(scrAttended);
  lv_label_set_text(lblHeart, "<3");
  lv_obj_set_style_text_color(lblHeart, lv_color_hex(0xf43f5e), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblHeart, &lv_font_montserrat_28, LV_PART_MAIN);
  lv_obj_align(lblHeart, LV_ALIGN_CENTER, 0, -35);

  lv_obj_t * lblTitle = lv_label_create(scrAttended);
  lv_label_set_text(lblTitle, "Pedido Atendido!");
  lv_obj_set_style_text_color(lblTitle, lv_color_hex(0xffffff), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblTitle, &lv_font_montserrat_18, LV_PART_MAIN);
  lv_obj_align(lblTitle, LV_ALIGN_CENTER, 0, 5);

  lblAttendedMsg = lv_label_create(scrAttended);
  lv_label_set_text(lblAttendedMsg, "Ajuda a caminho!");
  lv_obj_set_style_text_color(lblAttendedMsg, lv_color_hex(0xa7f3d0), LV_PART_MAIN);
  lv_obj_set_style_text_font(lblAttendedMsg, &lv_font_montserrat_14, LV_PART_MAIN);
  lv_obj_align(lblAttendedMsg, LV_ALIGN_CENTER, 0, 35);
}

void UIManager::showAttendedPopup(const String &label, const String &message) {
  if (lblAttendedMsg) {
    lv_label_set_text(lblAttendedMsg, message.c_str());
  }
  showScreen(SCREEN_ATTENDED);

  // Retorna à tela principal após 4 segundos
  lv_timer_t * timer = lv_timer_create([](lv_timer_t * t) {
    UIManager::showScreen(SCREEN_MAIN);
    lv_timer_del(t);
  }, 4000, NULL);
}

void UIManager::updateBattery(uint8_t percentage) {
  if (lblMainBattery) {
    String txt = String(percentage) + "%";
    lv_label_set_text(lblMainBattery, txt.c_str());
  }
}
