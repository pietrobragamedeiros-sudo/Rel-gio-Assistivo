/**
 * server.js — Servidor principal do Relógio Assistivo
 * Relógio Assistivo para Pessoas Autistas — TCC
 *
 * Acesso: http://localhost:3000
 */

const express = require('express');
const http    = require('http');
const WebSocket = require('ws');
const path    = require('path');
const { initDB, getOrCreateDevice, salvarPedido, marcarAtendido, getHistorico } = require('./database');

const app    = express();
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server });

const PORT = process.env.PORT || 3000;

// ---- Estado em memória ----
const devices = new Map(); // deviceId → { nome, pareado, pedido_atual, detalhes, ws_responsavel[] }

// ---- Inicializa banco ----
initDB();

// ---- Middleware ----
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'web')));

// ============================================================
// WEBSOCKET — Comunicação em tempo real
// ============================================================
wss.on('connection', (ws) => {
  console.log('[WS] Nova conexão');
  ws.deviceId = null;
  ws.tipo     = null;

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw);

      // ESP32 se identifica
      if (msg.tipo === 'esp32_connect') {
        ws.deviceId = msg.device_id;
        ws.tipo     = 'esp32';
        if (!devices.has(msg.device_id)) {
          devices.set(msg.device_id, { nome: msg.nome || 'Usuário', pareado: false, pedido_atual: 'nenhum', detalhes: '', responsaveis: [] });
        }
        console.log(`[WS] ESP32 conectado: ${msg.device_id}`);
        ws.send(JSON.stringify({ tipo: 'ok', mensagem: 'ESP32 registrado' }));
      }

      // Responsável se identifica
      if (msg.tipo === 'responsavel_connect') {
        ws.deviceId = msg.device_id;
        ws.tipo     = 'responsavel';
        if (devices.has(msg.device_id)) {
          devices.get(msg.device_id).responsaveis.push(ws);
          console.log(`[WS] Responsável conectado ao device: ${msg.device_id}`);
          ws.send(JSON.stringify({ tipo: 'ok', mensagem: 'Responsável registrado' }));
        }
      }

      // Novo pedido do ESP32
      if (msg.tipo === 'pedido' && ws.tipo === 'esp32') {
        const dev = devices.get(ws.deviceId);
        if (dev) {
          dev.pedido_atual = msg.pedido;
          dev.detalhes     = msg.detalhes || '';
          salvarPedido(ws.deviceId, msg.pedido, msg.detalhes || '');
          // Notifica todos os responsáveis conectados
          dev.responsaveis.forEach(r => {
            if (r.readyState === WebSocket.OPEN) {
              r.send(JSON.stringify({ tipo: 'novo_pedido', pedido: msg.pedido, detalhes: msg.detalhes }));
            }
          });
          console.log(`[WS] Pedido: ${msg.pedido}`);
        }
      }
    } catch (e) { console.error('[WS] Erro ao processar mensagem:', e.message); }
  });

  ws.on('close', () => {
    if (ws.tipo === 'responsavel' && ws.deviceId && devices.has(ws.deviceId)) {
      const dev = devices.get(ws.deviceId);
      dev.responsaveis = dev.responsaveis.filter(r => r !== ws);
    }
  });
});

// ============================================================
// API REST
// ============================================================

// Saúde do servidor
app.get('/api/health', (_, res) => res.json({ status: 'ok', uptime: process.uptime() }));

// Histórico de pedidos
app.get('/api/historico/:deviceId', (req, res) => {
  const hist = getHistorico(req.params.deviceId);
  res.json(hist);
});

// Marcar pedido como atendido (via REST)
app.post('/api/atendido/:deviceId', (req, res) => {
  const dev = devices.get(req.params.deviceId);
  if (dev) {
    dev.pedido_atual = 'nenhum';
    dev.detalhes     = '';
    // Notifica o ESP32 via WS se estiver conectado
    wss.clients.forEach(client => {
      if (client.deviceId === req.params.deviceId && client.tipo === 'esp32' && client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({ tipo: 'atendido' }));
      }
    });
  }
  res.json({ status: 'ok' });
});

// Status de um device
app.get('/api/status/:deviceId', (req, res) => {
  const dev = devices.get(req.params.deviceId);
  if (!dev) return res.json({ pedido_atual: 'nenhum', pareado: false });
  res.json({ pedido_atual: dev.pedido_atual, detalhes: dev.detalhes, pareado: dev.pareado });
});

// ============================================================
// Inicia o servidor
// ============================================================
server.listen(PORT, () => {
  console.log(`\n========================================`);
  console.log(`  RELÓGIO ASSISTIVO — SERVIDOR RODANDO`);
  console.log(`  Acesse: http://localhost:${PORT}`);
  console.log(`========================================\n`);
});
