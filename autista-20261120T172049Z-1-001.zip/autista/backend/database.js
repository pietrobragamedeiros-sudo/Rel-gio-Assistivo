/**
 * database.js — Gerenciamento de banco de dados SQLite
 * Relógio Assistivo — TCC
 */

const path = require('path');
const fs   = require('fs');

let db = null;

function initDB() {
  try {
    const Database = require('better-sqlite3');
    const dbPath   = path.join(__dirname, 'relogio.db');
    db = new Database(dbPath);

    db.exec(`
      CREATE TABLE IF NOT EXISTS devices (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id   TEXT UNIQUE NOT NULL,
        nome        TEXT DEFAULT 'Usuário',
        criado_em   DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS pairing_codes (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id   TEXT NOT NULL,
        codigo      TEXT NOT NULL,
        usado       INTEGER DEFAULT 0,
        criado_em   DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS requests (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id    TEXT NOT NULL,
        pedido       TEXT NOT NULL,
        detalhes     TEXT DEFAULT '',
        status       TEXT DEFAULT 'pendente',
        criado_em    DATETIME DEFAULT CURRENT_TIMESTAMP,
        atendido_em  DATETIME
      );
    `);

    console.log('✅ [DB] SQLite inicializado em:', dbPath);
    return true;
  } catch (err) {
    console.warn('⚠️  [DB] SQLite indisponível, usando armazenamento em memória:', err.message);
    return false;
  }
}

// ---- Operações com devices ----
function getOrCreateDevice(deviceId, nome = 'Usuário') {
  if (!db) return { id: 1, device_id: deviceId, nome };
  try {
    let dev = db.prepare('SELECT * FROM devices WHERE device_id = ?').get(deviceId);
    if (!dev) {
      db.prepare('INSERT INTO devices (device_id, nome) VALUES (?, ?)').run(deviceId, nome);
      dev = db.prepare('SELECT * FROM devices WHERE device_id = ?').get(deviceId);
    }
    return dev;
  } catch (e) { return { id: 1, device_id: deviceId, nome }; }
}

// ---- Operações com pedidos ----
function salvarPedido(deviceId, pedido, detalhes = '') {
  if (!db) return { id: Date.now(), pedido, detalhes };
  try {
    const info = db.prepare(
      'INSERT INTO requests (device_id, pedido, detalhes) VALUES (?, ?, ?)'
    ).run(deviceId, pedido, detalhes);
    return db.prepare('SELECT * FROM requests WHERE id = ?').get(info.lastInsertRowid);
  } catch (e) { return { id: Date.now(), pedido, detalhes }; }
}

function marcarAtendido(requestId) {
  if (!db) return;
  try {
    db.prepare(
      "UPDATE requests SET status='atendido', atendido_em=CURRENT_TIMESTAMP WHERE id=?"
    ).run(requestId);
  } catch (e) {}
}

function getHistorico(deviceId, limite = 20) {
  if (!db) return [];
  try {
    return db.prepare(
      "SELECT * FROM requests WHERE device_id=? ORDER BY criado_em DESC LIMIT ?"
    ).all(deviceId, limite);
  } catch (e) { return []; }
}

module.exports = { initDB, getOrCreateDevice, salvarPedido, marcarAtendido, getHistorico };
